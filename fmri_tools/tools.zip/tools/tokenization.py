import numpy as np
import pandas as pd
import nibabel as nib
from scipy.signal import find_peaks, peak_widths
from nilearn.masking import apply_mask
from joblib import Parallel, delayed
from tqdm import tqdm
import pyarrow as pa
import pyarrow.parquet as pq
import matplotlib.pyplot as plt
from tools.misc import generate_distinct_colors


class SignalsEvents:
    def __init__(self, func_file, mask_file):
        self.Y_img = nib.load(func_file, mmap=True)
        self.mask_img = nib.load(mask_file, mmap=True)
        self.Y = apply_mask(self.Y_img, self.mask_img)

    def detect_events(self, relative_heights=np.linspace(0.01, 1, 20), n_jobs=-1, desc='Event detection'):
        result = Parallel(n_jobs=n_jobs)(
            delayed(self.find_events_at_signal)(self.Y[:, s], relative_heights, s)
            for s in tqdm(range(self.Y.shape[1]), total=self.Y.shape[1], desc=desc)
        )
        self.events_features = pd.concat(result, ignore_index=True)
        self.relative_heights = relative_heights

    def find_events_at_signal(self, y, relative_heights, s=None):
        pks_loc, _ = find_peaks(y)
        n_peaks = len(pks_loc)
        data = {}
        if s is not None:
            data['signal_index'] = s
        if n_peaks > 0:
            pks_int = y[pks_loc]
            data['pks_loc'] = pks_loc
            data['pks_int'] = pks_int
            for rel_height in relative_heights:
                widths, width_heights, left_ips, right_ips = peak_widths(y, pks_loc, rel_height=rel_height)
                data['pks0_atrl_{:.2f}'.format(rel_height)] = left_ips
                data['pks1_atrl_{:.2f}'.format(rel_height)] = right_ips
                data['pks_int_atrl_{:.2f}'.format(rel_height)] = width_heights
        return pd.DataFrame(data)


    def save_tokens_to_file(self, file_tokens):
        table = pa.Table.from_pandas(self.events_features)
        pq.write_table(table, file_tokens)
        self.file_tokens = file_tokens


    def load_tokens_from_file(self, file_tokens):
        self.file_tokens = file_tokens
        self.events_features = pq.read_table(file_tokens).to_pandas()


    def tokenize_one_signal(self, signal_index):
        signal_features = self.events_features[self.events_features['signal_index'] == signal_index]
        y = self.Y[:, signal_index]
        pks_loc = signal_features['pks_loc'].values
        n_peaks = len(pks_loc)
        pks_0_gl = np.zeros(n_peaks)
        pks_1_gl = np.zeros(n_peaks)

        pks_0_gl[0] = signal_features['pks0_atrl_{:.2f}'.format(self.relative_heights[-1])].values[0]
        pks_1_gl[-1] = signal_features['pks1_atrl_{:.2f}'.format(self.relative_heights[-1])].values[-1]

        for i_pk in range(1, n_peaks):
            pk_prev = pks_loc[i_pk-1]
            pks_0_gl[i_pk] = signal_features['pks0_atrl_{:.2f}'.format(self.relative_heights[-1])].values[i_pk]
            for i_rl, rel_height in enumerate(self.relative_heights):
                pk_0 = signal_features['pks0_atrl_{:.2f}'.format(rel_height)].values[i_pk]
                if pk_prev >= pk_0:
                    rlchosen = self.relative_heights[i_rl-1]
                    pk_0_prev = signal_features['pks0_atrl_{:.2f}'.format(rlchosen)].values[i_pk]
                    pks_0_gl[i_pk] = pk_0_prev
                    break

        for i_pk in range(n_peaks - 1):
            pk_post = pks_loc[i_pk+1]
            pks_1_gl[i_pk] = signal_features['pks1_atrl_{:.2f}'.format(self.relative_heights[-1])].values[i_pk]
            for i_rl, rel_height in enumerate(self.relative_heights):
                pk_1 = signal_features['pks1_atrl_{:.2f}'.format(rel_height)].values[i_pk]
                if pk_post <= pk_1:
                    rlchosen = self.relative_heights[i_rl-1]
                    pk_1_prev = signal_features['pks1_atrl_{:.2f}'.format(rlchosen)].values[i_pk]
                    pks_1_gl[i_pk] = pk_1_prev
                    break

        pks_0_gl = np.floor(pks_0_gl).astype(int)
        pks_1_gl = np.ceil(pks_1_gl).astype(int)

        return pd.DataFrame({
            'signal_index': signal_index,
            'pks_0': pks_0_gl,
            'pks_loc': pks_loc,
            'pks_1': pks_1_gl
        })


    def tokenize_signals(self, n_jobs=-1, desc='Tokens generation'):
        result = Parallel(n_jobs=n_jobs)(
            delayed(self.tokenize_one_signal)(s)
            for s in tqdm(range(self.Y.shape[1]), total=self.Y.shape[1], desc=desc)
        )
        self.events_features = pd.concat(result, ignore_index=True)
        self.save_tokens_to_file(file_tokens='tokens.parquet')


    @staticmethod
    def plot_events_one_signal(y, pks_loc, pks_0, pks_1, timeline=None, figsize=(10, 2)):
        T = len(y)
        if timeline is None:
            timeaxis = np.arange(T)
            TR = 1
        else:
            timeaxis = timeline
            TR = timeline[1] - timeline[0]

        pks_int = y[pks_loc]
        fig, ax = plt.subplots(1, 1, figsize=figsize, sharex=True, sharey=True)
        ax.plot(timeaxis, y, label='y')
        ax.plot(timeaxis[pks_loc], pks_int, 'o', label='Peaks')

        tvector0 = timeaxis[np.floor(pks_0).astype(int)]
        tvector1 = timeaxis[np.ceil(pks_1).astype(int)]
        # colors = plt.cm.rainbow(np.linspace(0, 1, len(tvector1)))
        colors = generate_distinct_colors(len(tvector1))

        for i, (t0, t1) in enumerate(zip(tvector0, tvector1)):
            ax.axvspan(t0*TR, t1*TR, facecolor=colors[i], alpha=0.3)

        plt.legend()
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    func_file = "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz"
    mask_file = "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
    
    events = SignalsEvents(func_file, mask_file)
    events.detect_events()
    events.tokenize_signals()

    # Example of plotting events for a single signal
    signal_index = 0
    y = events.Y[:, signal_index]
    signal_data = events.events_features[events.events_features['signal_index'] == signal_index]
    events.plot_events_one_signal(y, signal_data['pks_loc'], signal_data['pks_0'], signal_data['pks_1'])


# import numpy as np
# from scipy.signal import find_peaks, peak_prominences
# import matplotlib.pyplot as plt
# from joblib import Parallel, delayed
# from pathlib import Path
# import shutil, os
# import nibabel as nib
# import numpy as np
# from scipy.signal import find_peaks, peak_prominences, peak_widths
# from joblib import Parallel, delayed
# from tqdm import tqdm

# from nilearn.masking import apply_mask, unmask

# from misc import map_unmasked3d_to_maskedidx
# import numpy as np
# import scipy.sparse as sparse
# import numpy as np
# import pandas as pd
# import pyarrow as pa
# import pyarrow.parquet as pq
# import nibabel as nib
# from scipy.signal import find_peaks, peak_widths
# import numpy as np
# import pandas as pd
# from scipy.signal import find_peaks, peak_widths
# import pyarrow as pa
# import pyarrow.parquet as pq

# import nibabel as nib
# import random
# from scipy.ndimage import label as label_func
# import pandas as pd
# import pyarrow.parquet as pq
# import numpy as np
# from joblib import Parallel, delayed, cpu_count, Memory
# from tqdm import tqdm
# from tools.misc import generate_distinct_colors












# class SignalsEvents:


#     def __init__(self, func_file, mask_file):
#         self.Y_img = nib.load(func_file, mmap=True)
#         self.mask_img = nib.load(mask_file, mmap=True)
#         self.Y = apply_mask(self.Y_img, self.mask_img)
#         return


#     def detect_events(self, 
#                       relative_heights=np.linspace(0.01, 1, 20),
#                       n_jobs=-1,
#                       desc=f'Event detection'):
        
#         result = Parallel(n_jobs=n_jobs)(delayed(self.find_events_at_signal)(
#             self.Y[:, s],
#             relative_heights,
#             s
#             ) for s in tqdm(range(self.Y.shape[1]), total=self.Y.shape[1], desc=desc))
#         self.events_features = pd.concat(result, ignore_index=True)
#         self.relative_heights = relative_heights


#     def find_events_at_signal(self, y, relative_heights, s=None):

#         pks_loc, _ = find_peaks( y )
#         n_peaks = len(pks_loc)
#         data = dict()
#         if s is not None:
#             data['signal_index'] = s
#         if n_peaks > 0:
#             pks_int = y[ pks_loc ]
#             data['pks_loc'] = pks_loc
#             data['pks_int'] = pks_int
#             for i, rel_height in enumerate(relative_heights):
#                 widths, width_heights, left_ips, right_ips = peak_widths(
#                     y,
#                     pks_loc,
#                     rel_height=rel_height
#                 )
#                 data[f'pks0_atrl_{rel_height:.2f}'] = left_ips
#                 data[f'pks1_atrl_{rel_height:.2f}'] = right_ips
#                 data[f'pks_int_atrl_{rel_height:.2f}'] = width_heights
#         return pd.DataFrame(data)


#     def load_events_from_file(self, file_events):

#         self.file_events = file_events
#         self.events_features = pq.read_table(file_events).to_pandas()


#     def save_events_to_file(self, file_tokens):

#         table = pa.Table.from_pandas( self.events_features )
#         pq.write_table(table, file_tokens)
#         self.file_tokens = file_tokens


#     def get_features_atrl(self, signal_index, rel_height):
#         signal_features = self.events_features[self.events_features['signal_index'] == signal_index]
#         return signal_features[[f'pks0_atrl_{rel_height:.2f}', 
#                                 f'pks1_atrl_{rel_height:.2f}', 
#                                 f'pks_int_atrl_{rel_height:.2f}']]


#     def get_peaks_locs(self, signal_index):
#         return self.events_features[self.events_features['signal_index'] == signal_index][['pks_loc']].values


#     def get_peaks_ints(self, signal_index):
#         return self.events_features[self.events_features['signal_index'] == signal_index][['pks_int']].values


#     def get_relative_heights(self):

#         column_names = pq.read_schema(self.file_events).names
#         rel_heights = np.array(list(map(float, [col.split('_atrl_')[1] 
#                                                 for col in column_names 
#                                                 if '_atrl_' in col])))
#         return sorted(np.unique(rel_heights))

#     def tokenize_one_signal(self, signal_index):

#         signal_features = self.events_features[self.events_features['signal_index'] == signal_index]
#         # print(signal_features.columns)
#         y = self.Y[:, signal_index]
#         pks_loc = signal_features['pks_loc'].values
        
#         n_peaks = len(pks_loc)
#         pks_0_gl = np.zeros(n_peaks)
#         pks_0_gl[0] = signal_features[f'pks0_atrl_{self.relative_heights[-1]:.2f}'].values[0]
#         for i_pk, pk_loc in enumerate(pks_loc[1:], 1):
#             pk_current = pks_loc[i_pk]
#             pk_prev = pks_loc[i_pk-1]
#             # print(i_pk, pk_current, pk_prev)
#             pks_0_gl[i_pk] = signal_features[f'pks0_atrl_{self.relative_heights[-1]:.2f}'].values[i_pk]
#             for i_rl, rel_height in enumerate(self.relative_heights):
#                 pk_0 = signal_features[f'pks0_atrl_{rel_height:.2f}'].values[i_pk]
#                 if pk_prev >= pk_0: # if I move to this point then I add neighbor peak 
#                     # If this happens I will end on the previous relative height value
#                     rlchosen = self.relative_heights[i_rl-1]
#                     pk_0_prev = signal_features[f'pks0_atrl_{rlchosen:.2f}'].values[i_pk]
#                     # print(pk_0, pk_0_prev, 'at', rlchosen)
#                     pks_0_gl[i_pk] = pk_0_prev
#                     break

#         pks_1_gl = np.zeros(n_peaks)
#         pks_1_gl[-1] = signal_features[f'pks1_atrl_{self.relative_heights[-1]:.2f}'].values[-1]
#         for i_pk, pk_loc in enumerate(pks_loc[:-1]):
#             pk_current = pks_loc[i_pk]
#             pk_post = pks_loc[i_pk+1]
#             # print(i_pk, pk_current, pk_post)
#             pks_1_gl[i_pk] = signal_features[f'pks1_atrl_{self.relative_heights[-1]:.2f}'].values[i_pk]
#             for i_rl, rel_height in enumerate(self.relative_heights):
#                 pk_1 = signal_features[f'pks1_atrl_{rel_height:.2f}'].values[i_pk]
#                 if pk_post <= pk_1: # if I move to this point then I add neighbor peak 
#                     # If this happens I will end on the previous relative height value
#                     rlchosen = self.relative_heights[i_rl-1]
#                     pk_1_prev = signal_features[f'pks1_atrl_{rlchosen:.2f}'].values[i_pk]
#                     # print(pk_1, pk_1_prev, 'at', rlchosen)
#                     pks_1_gl[i_pk] = pk_1_prev
#                     break
#                 #     print(rel_height)

#         pks_0_gl = np.floor(pks_0_gl).astype(int)
#         pks_1_gl = np.ceil(pks_1_gl).astype(int)

#         # for i_pk in range(n_peaks):
#         #     print(pks_0_gl[i_pk], pks_loc[i_pk], pks_1_gl[i_pk])
#         return pd.DataFrame(
#             {'signal_index': signal_index,
#              'pks_0': pks_0_gl,
#              'pks_loc': pks_loc,
#              'pks_1': pks_1_gl }
#              )


#     def tokenize_signals(self,
#                          n_jobs=-1,
#                          desc=f'Tokens generation'):
        
#         result = Parallel(n_jobs=n_jobs)(delayed(self.tokenize_one_signal)(s) 
#                                          for s in tqdm(range(self.Y.shape[1]), 
#                                                        total=self.Y.shape[1], 
#                                                        desc=desc))
#         self.events_features = pd.concat(result, ignore_index=True)
#         self.save_events_to_file(file_tokens='tokens.parquet')
        
#         # self.relative_heights = relative_heights

#     def plot_events_one_signal(y, pks_loc, pks_0, pks_1,
#                                timeline=None,
#                                figsize=(10, 2)):

#         T = len(y)
#         n_relative_heights = len(self.relative_heights)
#         if timeline is None:
#             timeaxis = np.arange(T)
#             TR = 1
#         else:
#             timeaxis = timeline
#             TR = timeline[1]-timeline[0]

#         pks_int = y[pks_loc]
#         fig, ax = plt.subplots(1, 1, figsize=figsize, sharex=True, sharey=True)
#         ax.plot(timeaxis, y, label='y')
#         ax.plot(timeaxis[pks_loc], pks_int, 'o', label='Peaks')
#         tvector0 = timeaxis[np.floor(pks_0).astype(int)]
#         tvector1 = timeaxis[np.ceil(pks_1).astype(int)]
#         color = generate_distinct_colors(len(tvector1))
#         for i, (t0, t1) in enumerate(zip(tvector0, tvector1)):
#             ax.axvspan(t0*TR, t1*TR, facecolor=color[i], alpha=1.)
#         plt.tight_layout()
#         plt.show()




# if __name__ == "__main__":
    
#     func_file = "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz"
#     mask_file = "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
    
#     events = SignalsEvents(func_file, mask_file)
#     events.detect_events()
#     events.tokenize_signals()






#     # def plot_events_panel_atrl(y, pkscache, signal_index, relative_heights, 
# #                        timeline=None, 
# #                        figsize=(10, 2)):

# #     T = len(y)
# #     n_relative_heights = len(relative_heights)
# #     timeaxis = np.arange(T) if timeline is None else timeline
# #     TR = timeaxis[1]-timeaxis[0]

# #     pks_loc_int = pkscache.get_peaks_and_intensities(signal_index)
# #     pks_loc, pks_int = pks_loc_int['pks_loc'], pks_loc_int['pks_int']

# #     nrows = 4
# #     ncols = (n_relative_heights + 2) // nrows
# #     fig, axes = plt.subplots(nrows, ncols, figsize=figsize, sharex=True, sharey=True)
# #     axes = axes.flatten()
# #     for ipk, rel_height in enumerate(relative_heights):
# #         ax = axes[ipk]
# #         features = pkscache.get_features_atrl(signal_index, rel_height)
# #         ax.plot(timeaxis, y, label='y')
# #         ax.plot(timeaxis[pks_loc], pks_int, 'o', label='Peaks')
# #         tvector0 = timeaxis[np.floor(features[f'pks0_atrl_{rel_height:.2f}']).astype(int)]
# #         tvector1 = timeaxis[np.ceil(features[f'pks1_atrl_{rel_height:.2f}']).astype(int)]
# #         int_atrl = features[f'pks_int_atrl_{rel_height:.2f}']
# #         # ax.plot(tvector0, int_atrl, 'x', label=f'{rel_height}')
# #         for t0, t1 in zip(tvector0, tvector1):
# #             ax.axvspan(t0*TR, t1*TR, facecolor='C2', alpha=0.5)
# #         ax.set_title(f'{rel_height:.2f}')
# #     for ax in axes[n_relative_heights:]:
# #         fig.delaxes(ax)
# #     plt.tight_layout()
# #     plt.show()

