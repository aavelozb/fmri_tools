import os, sys, shutil, time
import numpy as np
import matplotlib.pyplot as plt
from joblib import Parallel, delayed
from tqdm import tqdm
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import nibabel as nib
from nilearn.masking import apply_mask

# imports from local files
from tools.misc import hrf_func


def convolve_pytorch_batch(X, H):
    N, T = X.shape
    Th, _ = H.shape
    X = X.unsqueeze(0)  # Shape: (1, N, T), input shape for grouped convolution
    H = H.t().unsqueeze(1)  # Shape: (N, 1, Th), batch convolution
    H = H.flip(2)
    Y = F.conv1d(X, H, padding=Th-1, groups=N)[:, :, :T].squeeze().t()  # Shape: (T, N)
    return Y

def lasso_loss_batch(Y, X, H, alpha):
    Y_pred = convolve_pytorch_batch(X, H)
    l2_loss = torch.sum((Y - Y_pred) ** 2)
    l1_loss = alpha * torch.sum(torch.abs(X))
    return l2_loss + l1_loss

def deconv_x_lasso_batch(Y_batch, H_batch, Xest_batch, lambdax, 
                         learning_rate=0.01, num_iterations=1000):
    optimizer = torch.optim.Adam([Xest_batch], lr=learning_rate)
    Y_batch = torch.from_numpy(Y_batch).float()
    H_batch = torch.from_numpy(H_batch).float()
    for it in range(num_iterations):
        optimizer.zero_grad()
        loss = lasso_loss_batch(Y_batch, Xest_batch, H_batch, lambdax)
        loss.backward()
        optimizer.step()
    return Xest_batch.detach().numpy().T

def deconv_x_lasso(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True,
                   learning_rate=0.01, num_iterations=1000, batch_size = 100):
    T, N = Y.shape
    Th = H.shape[0]
    Nhrfs = H.shape[1] if H.ndim > 1 else 1
    if verbose:
        start_time = time.time()

    N_batches = int(np.ceil(N / batch_size))
    params = []
    for i in range(0, N, batch_size):
        # print(f'batch {i//batch_size + 1} / {N_batches}')
        Y_batch = Y[:, i:i+batch_size]
        H_batch = H[:, i:i+batch_size] 
        Xest_batch = torch.zeros(Y_batch.shape[1], T, requires_grad=True)
        params.append({'Y_batch': Y_batch, 
                       'H_batch': H_batch, 
                       'Xest_batch': Xest_batch, 
                       'lambdax': lambdax,
                       'learning_rate': learning_rate,
                       'num_iterations': num_iterations
                       })
    
    result = Parallel(n_jobs=n_jobs)(
            delayed(deconv_x_lasso_batch)(**p) for p in tqdm(params, total=len(params), desc=f'Processing batch'))

    Xest = np.column_stack(result)
    if verbose:
        print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    return Xest



if __name__ == "__main__":

    Y_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz")
    mask_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz")
    Y = apply_mask(Y_img, mask_img)
    # Y = Y[:,:1000]
    T, N = Y.shape
    Th = 40
    TR = 0.5
    timeline = np.arange(T) * TR
    h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
    H = np.column_stack(N*[h]) # (40, 23238)

    Xest = deconv_x_lasso(Y, H, lambdax=2, verbose=True,
                    learning_rate=0.01, 
                    num_iterations=1000,
                    batch_size = 100)

    plt.figure(figsize=(12, 6))
    plt.plot(timeline, Y[:, 100], label='y')
    plt.plot(timeline, Xest[:, 100], label='$\hat{x}$')
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    plt.show()

# FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.


# from tools.preprocessing import linear_interpolate_signals
# timeline2 = np.linspace(min(timeline), max(timeline), T//2)
# Y2 = linear_interpolate_signals(Y, timeline, timeline2, parallel=True, verbose=False, n_jobs=-1)
# H2 = linear_interpolate_signals(H, timeline[:Th], timeline2[:Th], parallel=True, verbose=False, n_jobs=-1)





# def deconv_x_lasso(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True,
#                    learning_rate=0.01, num_iterations=1000):

#     T, N = Y.shape
#     Th = H.shape[0]
#     Nhrfs = H.shape[1] if H.ndim > 1 else 1  
#     Xest = torch.zeros(N, T, requires_grad=True)
#     optimizer = torch.optim.Adam([Xest], lr=learning_rate)
#     Y = torch.from_numpy(Y).float()
#     H = torch.from_numpy(H).float()

#     if verbose:
#         start_time = time.time()

#     ibatch=0
#     for it in tqdm(range(num_iterations), total=num_iterations, desc=f'(batch {ibatch})'):
#         optimizer.zero_grad()
#         loss = lasso_loss_batch(Y, Xest, H, lambdax)
#         loss.backward()
#         optimizer.step()

#     if verbose:
#         print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

#     return Xest.detach().numpy().T


# def deconv_x_lasso(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True,
#                    learning_rate=0.01, num_iterations=1000):

#     T, N = Y.shape
#     Th = H.shape[0]
#     Nhrfs = H.shape[1] if H.ndim > 1 else 1
#     if verbose:
#         start_time = time.time()

#     batch_size = 100
#     N_batches = int(np.ceil(N / batch_size))
#     Y_batches = []
#     H_batches = []
#     for i in range(0, N, batch_size):
#         Y_batch = Y[:, i:i+batch_size]
#         H_batch = H[:, i:i+batch_size] 
#         Nsignals_batch = Y_batch.shape[1]
#         # Y_batches.append(  )
#         # H_batches.append( H[:, i:i+batch_size] )
#         Xest_batch = torch.zeros(Nsignals_batch, T, requires_grad=True)
#         optimizer = torch.optim.Adam([Xest_batch], lr=learning_rate)
#         Y_batch = torch.from_numpy(Y_batch).float()
#         H_batch = torch.from_numpy(H_batch).float()

#         for it in tqdm(range(num_iterations), total=num_iterations, desc=f'batch {i//batch_size + 1} / {N_batches}'):
#             optimizer.zero_grad()
#             loss = lasso_loss_batch(Y_batch, Xest_batch, H_batch, lambdax)
#             loss.backward()
#             optimizer.step()

#         Xest_batch = Xest_batch.detach().numpy().T

#     if verbose:
#         print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

#     return Xest_batch





# import torch
# import torch.nn.functional as F
# import numpy as np
# from tqdm import tqdm
# import time

# def convolve_pytorch_batch(X, H):
#     N, T = X.shape
#     print(N, T)
#     Th, _ = H.shape
#     X = X.unsqueeze(0)  # Shape: (1, N, T), input shape for grouped convolution
#     H = H.t().unsqueeze(1)  # Shape: (N, 1, Th), batch convolution
#     H = H.flip(2)
#     Y = F.conv1d(X, H, padding=Th-1, groups=N)[:, :, :T].squeeze().t()  # Shape: (T, N)
#     return Y



# def lasso_loss_batch(Y, X, H, alpha):
#     Y_pred = convolve_pytorch_batch(X, H)
#     l2_loss = torch.sum((Y - Y_pred) ** 2)
#     l1_loss = alpha * torch.sum(torch.abs(X))
#     return l2_loss + l1_loss

# def deconv_x_lasso(Y, H, lambdax, batch_size=1000, learning_rate=0.01,
#                    num_iterations=1000, verbose=True):
#     """
#     Estimate X using Lasso optimization with batch processing.
    
#     Args:
#         Y (numpy.ndarray): Observed signals of shape (T, N)
#         H (numpy.ndarray): Convolution kernels of shape (Th, N)
#         lambdax (float): Regularization parameter
#         batch_size (int): Number of signals to process per batch
#         learning_rate (float): Learning rate for optimization
#         num_iterations (int): Number of optimization iterations per batch
#         verbose (bool): Whether to print progress and timing information
    
#     Returns:
#         numpy.ndarray: Estimated X of shape (T, N)
#     """
#     T, N = Y.shape
#     Th = H.shape[0]
    
#     # Convert to PyTorch tensors
#     Y = torch.from_numpy(Y).float()
#     H = torch.from_numpy(H).float()
    
#     # Initialize estimated X
#     Xest_full = torch.zeros(N, T)

#     if verbose:
#         start_time = time.time()

#     # Process in batches
#     for i in range(0, N, batch_size):
#         if verbose:
#             print(f"Processing batch {i // batch_size + 1} / {int(np.ceil(N / batch_size))}")
        
#         # Select the current batch
#         Y_batch = Y[:, i:i+batch_size].t()  # Shape: (batch_size, T)
#         H_batch = H[:, i:i+batch_size]      # Shape: (Th, batch_size)

#         # Initialize X for this batch
#         Xest_batch = torch.zeros(Y_batch.shape[0], T, requires_grad=True)

#         # Optimizer for this batch
#         optimizer = torch.optim.Adam([Xest_batch], lr=learning_rate)

#         # Optimize for this batch
#         for _ in range(num_iterations):
#             optimizer.zero_grad()
#             loss = lasso_loss_batch(Y_batch, Xest_batch, H_batch.t(), lambdax)
#             loss.backward()
#             optimizer.step()

#         # Store the result for this batch
#         Xest_full[i:i+batch_size] = Xest_batch.detach()

#     if verbose:
#         print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

#     return Xest_full.numpy().T



