import os
import numpy as np
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt

import nibabel as nib
import scipy.io as sio
from scipy import stats, signal
from scipy.sparse import lil_matrix
import rsHRF_toolbox.rest_filter as rest_filter
import rsHRF_toolbox.iterative_wiener_deconv as iterative_wiener_deconv
import rsHRF_toolbox.basis_functions as basis_functions
import rsHRF_toolbox.hrf_estimation as hrf_estimation
import rsHRF_toolbox.parameters as parameters
from nilearn.masking import apply_mask, unmask
from nilearn.image import resample_to_img

# !pwd
# import os, sys
# path = os.path.abspath(os.getcwd())
# path = path[0]

# path_rsHRF = path.split(os.path.sep)+['src_rsHRF']
# sys.path.insert(0, os.path.join(*path_rsHRF))

# # path_pyyawt = path.split(os.path.sep)+['src_rsHRF', 'rsHRFlocal', 'pyyawt']
# # sys.path.insert(0, os.path.join(*path_pyyawt))

# !cd src_rsHRF
# !pwd


p_jobs = 8

import warnings
warnings.filterwarnings("ignore")

################################### Data generation for testing

# from BalloonModelNetwork import generateConnectivityMatrix, generateNetworkEvents, BalloonModel
# Nsamples = 300
# TR = 1
# Nnds = 10 # This is the number of nodes
# Nconn = 10 # This is the number of connections (assigned randomly) 
# timeline = TR * np.arange( Nsamples )
# C = generateConnectivityMatrix(Nnds, Nconn)
# U = generateNetworkEvents(timeline, Nnds, nblocks=5, duration_range=(1,1))
# bm = BalloonModel(timeline, U, C)
# bm.StimulusToNeural()
# bm.NeuraltoFlowin()
# bm.FlowinToBold()
# bm.add_noise()
# TR = bm.t_bold[1] - bm.t_bold[0]



# fname_vol = 
# fname_func = "/Users/alejandro/data/voice-nonvoice-bids/sub003/func/swbold.nii.gz"
# fname_mask = "/Users/alejandro/nilearn_data/aal_SPM12/aal/atlas/AAL.nii"

# fname_func = "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz"
# fname_mask = "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
fname_func = "/Users/alejandro/data/voice-nonvoice-bids/sub003/func/swbold.nii.gz"
fname_mask = "/Users/alejandro/nilearn_data/aal_SPM12/aal/atlas/AAL.nii"
fname_anat = "/Users/alejandro/data/voice-nonvoice-bids/sub003/anat/wmsub003_Ed-0014-00001-000192-01.nii"
func_img = nib.load(fname_func)
anat_img = nib.load(fname_anat, mmap=True)
mask_img = nib.load(fname_mask, mmap=True)
mask_img = resample_to_img(mask_img, anat_img, interpolation='nearest')
mask_img = nib.Nifti1Image((mask_img.get_fdata() > 0).astype(int), mask_img.affine, mask_img.header)
Y = apply_mask(func_img, mask_img)
print(Y.shape)
data1 = Y
TR = 2





################################### rsHRF parameters

# estimation options
BF =   ['canon2dd', 'canon2dd', 'gamma', 'fourier', 'fourier w hanning', 'FIR', 'sFIR']
Name = ['Canonical HRF (with time derivative)', 
        'Canonical HRF (with time and dispersion derivatives)',
        'Gamma functions', 
        'Fourier set', 
        'Fourier set (Hanning)',
        'FIR', 
        'sFIR']

temporal_mask = []
wiener = False

para = {'TR': TR, 'output_dir': 'outputs', 'output_name': 'test_balloon'}
para['estimation'] = 'canon2dd'
para['TD_DD'] = 1
para['order'] = 3
para['passband'] = [0.01, 0.08]
para['T'] = 4
para['T0'] = 1
para['min_onset_search'] = 4
para['max_onset_search'] = 8
para['AR_lag'] = 1
para['len'] = 24
para['dt'] = para['TR']/para['T']
para['lag'] = np.arange(np.fix(para['min_onset_search'] / para['dt']), np.fix(para['max_onset_search'] / para['dt']) + 1, dtype=np.int32)
para['thr'] = 1
if para['TR'] <= 2: para['localK'] = 1
else: para['localK'] = 2
if para['T'] == 1: para['T0'] = 1

# print the parameters
for k in para: print(k, para[k])

if not os.path.isdir(para['output_dir']): os.mkdir(para['output_dir'])

if data1.ndim == 1: data1 = np.expand_dims(data1, axis=1)
nobs = data1.shape[0]
bold_sig = stats.zscore(data1, ddof=1)

# plt.figure(1)
# for i in range(data1.shape[1]):
#     plt.plot(bold_sig[:, i])
# print(bold_sig.shape)

if len(temporal_mask) > 0 and len(temporal_mask) != nobs:
    raise ValueError ('Inconsistency in temporal_mask dimensions.\n' + 'Size of mask: ' + str(len(temporal_mask)) + '\n' + 'Size of time-series: ' + str(nobs))
bold_sig = np.nan_to_num(bold_sig)
bold_sig_deconv = rest_filter.rest_IdealFilter(bold_sig, para['TR'], para['passband'])   
bold_sig = rest_filter.rest_IdealFilter(bold_sig, para['TR'], para['passband'])   

plt.figure(2)
for i in range(data1.shape[1]):
    plt.plot(bold_sig[:, i])
plt.show()

data_deconv  = np.zeros(bold_sig.shape)
event_number = np.zeros((1, bold_sig.shape[1]))
print('Retrieving HRF ...')
if not (para['estimation'] == 'sFIR' or para['estimation'] == 'FIR'):
    # Estimate HRF for the fourier / hanning / gamma / cannon basis functions
    bf = basis_functions.get_basis_function(bold_sig.shape, para)
    beta_hrf, event_bold = hrf_estimation.compute_hrf(bold_sig, para, temporal_mask, p_jobs, bf=bf)
    hrfa = np.dot(bf, beta_hrf[np.arange(0, bf.shape[1]), :])
else:
    # Estimate HRF for FIR and sFIR
    para['T'] = 1        
    beta_hrf, event_bold = hrf_estimation.compute_hrf(bold_sig, para, temporal_mask, p_jobs)
    hrfa = beta_hrf[:-1,:]
nvar = hrfa.shape[1]
PARA = np.zeros((3, nvar))
for voxel_id in range(nvar):
    hrf1 = hrfa[:, voxel_id]
    PARA[:, voxel_id] = parameters.wgr_get_parameters(hrf1, para['TR'] / para['T'])
print('Done')

print('Deconvolving HRF ...')
if para['T'] > 1:
    hrfa_TR = signal.resample_poly(hrfa, 1, para['T'])
else:
    hrfa_TR = hrfa
for voxel_id in range(nvar):
    hrf = hrfa_TR[:, voxel_id]
    if not wiener:
        H = np.fft.fft(
            np.append(hrf,
                        np.zeros((nobs - max(hrf.shape), 1))), axis=0)
        M = np.fft.fft(bold_sig_deconv[:, voxel_id])
        data_deconv[:, voxel_id] = \
            np.fft.ifft(H.conj() * M / (H * H.conj() + .1*np.mean((H * H.conj()))))
    else:
        data_deconv[:, voxel_id] = iterative_wiener_deconv.rsHRF_iterative_wiener_deconv(bold_sig_deconv[:, voxel_id], hrf)
    event_number[:, voxel_id] = np.amax(event_bold[voxel_id].shape)
print('Done')


print('Saving Output ...')
sub_save_dir = para['output_dir']
name = para['output_name']
if not os.path.isdir(sub_save_dir): os.makedirs(sub_save_dir, exist_ok=True)
dic = {'para': para, 'hrfa': hrfa, 'event_bold': event_bold, 'PARA': PARA}
ext = '_hrf.mat'
dic['event_number'] = event_number
dic['data_deconv']  = data_deconv
ext = '_hrf_deconv.mat'
sio.savemat(os.path.join(sub_save_dir, name + ext), dic)
HRF_para_str = ['height', 'T2P', 'FWHM']

pos = 0
while pos < hrfa_TR.shape[1]:
    if np.any(hrfa_TR[:,pos]): break
    pos += 1
event_plot = lil_matrix((1, nobs))
if event_bold.size: event_plot[:, event_bold[pos]] = 1
else: print("No Events Detected!")

event_plot = np.ravel(event_plot.toarray())

plt.figure()
plt.plot(para['TR'] * np.arange(1, np.amax(hrfa_TR[:, pos].shape) + 1), hrfa_TR[:, pos], linewidth=1)
plt.xlabel('time (s)')
plt.savefig(os.path.join(sub_save_dir, name + '_hrf_plot.png'))

plt.figure()
plt.plot(para['TR'] * np.arange(1, nobs + 1),
            np.nan_to_num(stats.zscore(bold_sig[:, pos], ddof=1)),
            linewidth=1)
plt.plot(para['TR'] * np.arange(1, nobs + 1),
            np.nan_to_num(stats.zscore(data_deconv[:, pos], ddof=1)),
            color='r', linewidth=1)
markerline, stemlines, baseline = plt.stem(para['TR'] * np.arange(1, nobs + 1), event_plot)
plt.setp(baseline, 'color', 'k', 'markersize', 1)
plt.setp(stemlines, 'color', 'k')
plt.setp(markerline, 'color', 'k', 'markersize', 3, 'marker', 'd')
plt.legend(['BOLD', 'Deconvolved BOLD', 'Events'], loc='best')
plt.xlabel('time (s)')
plt.savefig(os.path.join(sub_save_dir, name + '_deconvolution_plot.png'))   
print('Done')