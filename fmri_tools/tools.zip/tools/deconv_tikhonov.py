import os, sys, shutil, time
import numpy as np
import matplotlib.pyplot as plt
from math import sqrt
from scipy import signal, interpolate, linalg
from scipy.linalg import toeplitz, solve_triangular
from joblib import Parallel, delayed, cpu_count, Memory
from tqdm import tqdm

# imports from local files
from tools.misc import hrf_func
# from data_manipulation import map_unmasked3d_to_maskedidx




######################### function to perform deconvolution Tikhonov method
# The implementation logic is that it receives a matrix with signals Y 

##################### HRF deconvolution

def deconv_h_tikhonov_single_signal(yi, xi, lambdahi, Th, T):
    Xi = np.column_stack((np.ones(T), toeplitz(xi, np.zeros(Th))))
    # Xi = toeplitz(xi, np.zeros(Th))
    # XiTXi = Xi.T @ Xi
    XiTXi = np.einsum('ji,jk->ik', Xi, Xi)
    XiTXi[np.diag_indices_from(XiTXi)] += lambdahi
    Hest = solve_triangular(XiTXi, Xi.T @ yi, lower=False)
    return Hest[1:], Hest[0]


def deconv_h_tikhonov(Y, X, lambdah, Th, bias=True, parallel=True, n_jobs=-1, verbose=True):
    print(30*'-' + ' HRF estimation - Tikhonov')
    T, N = Y.shape
    if verbose:
        start_time = time.time()
    
    p = [{'yi': Y[:, s], 'xi': X[:, s], 'lambdahi': lambdah, 'Th': Th, 'T': T} for s in range(Y.shape[1])]
    if parallel:
        results = Parallel(n_jobs=n_jobs)(delayed(deconv_h_tikhonov_single_signal)(**p[s]) for s in tqdm(
            range(N), total=N, desc=f'(parallel processing)'))
    else:
        results = [deconv_h_tikhonov_single_signal(**p[s]) for s in tqdm(
            range(N), total=N, desc='(parallel processing: off)')]

    if verbose:
        print(f'Elapsed time HRF estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    Hest, Hest_bias = zip(*results)
    return np.array(Hest).T, np.array(Hest_bias)


##################### X deconvolution

def deconv_x_tikhonov_voxelwise_hrf(yi, hi, lambdaxi, T):
    Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
    HiTHi = Hi.T @ Hi
    HiTHi[np.diag_indices_from(HiTHi)] += lambdaxi
    Xest = solve_triangular(HiTHi, Hi.T @ yi, lower=False)
    return Xest[1:], Xest[0]

def deconv_x_tikhonov_single_hrf(yi, HiTHi, HiT):
    Xest = solve_triangular(HiTHi, HiT @ yi, lower=False)
    return Xest[1:], Xest[0]

def deconv_x_tikhonov(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True):
    print(30*'-' + ' X estimation - Tikhonov')
    T, N = Y.shape
    Th = H.shape[0]
    Nhrfs = H.shape[1] if H.ndim > 1 else 1
    if verbose: 
        start_time = time.time()

    if Nhrfs == 1:
        H_padded = np.pad(H, (0, T - Th), 'constant') if T > Th else H
        Hi = np.column_stack((np.ones(T), toeplitz(H_padded, np.zeros(T))))
        HiTHi = Hi.T @ Hi
        HiTHi[np.diag_indices_from(HiTHi)] += lambdax
        HiT = Hi.T
        p = [{'yi': Y[:, s], 'HiTHi': HiTHi, 'HiT': HiT} for s in range(Y.shape[1])]
        decfun = deconv_x_tikhonov_single_hrf
    else:
        H_padded = np.pad(H, ((0, T - Th), (0, 0)), 'constant') if T > Th else H
        p = [{'yi': Y[:, s], 'hi': H_padded[:, s], 'lambdaxi': lambdax, 'T': T} for s in range(Y.shape[1])]
        decfun = deconv_x_tikhonov_voxelwise_hrf

    if parallel:
        results = Parallel(n_jobs=n_jobs)(delayed(decfun)(**p[s]) for s in tqdm(range(N), total=N, desc=f'(parallel processing)'))
    else:
        results = [decfun(**p[s]) for s in tqdm(range(N), total=N, desc='(parallel processing: off)')]

    if verbose:
        print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    Xest, Xest_bias = zip(*results)
    return np.array(Xest).T, np.array(Xest_bias)


if __name__ == "__main__":

    from tools.misc import hrf_func

    T = 1000
    Th = 40
    TR = 0.5

    timeline = np.arange(T) * TR
    x_true = np.zeros(T)
    x_true[100] = 1
    x_true[700] = 1

    h_true = hrf_func(timeline)
    H_true = toeplitz(h_true, np.zeros(T))
    y = H_true @ x_true
    # print(x_true.shape, y.shape, h_true.shape, H_true.shape)

    h0 = hrf_func(timeline[:Th], delay=3, disp=1)
    Y = y[:, np.newaxis]
    X = x_true[:, np.newaxis]
    hest, hbias = deconv_h_tikhonov(Y, X, lambdah=0.5, Th=Th, bias=True, parallel=True, n_jobs=-1, verbose=True)

    plt.figure()
    plt.plot(timeline, x_true)
    plt.plot(timeline, y)
    plt.figure()
    plt.plot(timeline[:Th], h_true[:Th])
    plt.plot(timeline[:Th], h0)
    plt.plot(timeline[:Th], hest.flatten())
    plt.show()