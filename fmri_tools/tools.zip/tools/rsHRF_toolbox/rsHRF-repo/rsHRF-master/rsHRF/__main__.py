from rsHRF import CLI

CLI.main()
