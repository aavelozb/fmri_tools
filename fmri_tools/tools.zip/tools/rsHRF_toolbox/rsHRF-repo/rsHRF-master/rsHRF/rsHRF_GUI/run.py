from .gui_windows.main import Main 

def run():
    Main()