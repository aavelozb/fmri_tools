.. _ref-resources:

=========
Resources
=========

Code
----

The `GitHub repository`_ is now the main
code repository.

If you are using the Mercurial repository at Bitbucket, please switch
to Git/GitHub and follow  for development updates.


Questions and bug reports
-------------------------

Use `GitHub Issues`_ to post questions
and open tickets.



Articles
--------

.. _GitHub repository: https://github.com/holgern/pyyawt
.. _GitHub Issues: https://github.com/holgern/pyyawt/issues
