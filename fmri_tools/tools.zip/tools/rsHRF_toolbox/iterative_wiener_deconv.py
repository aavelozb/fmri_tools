import numpy as np
from scipy.signal import convolve

def rsHRF_iterative_wiener_deconv(y, h, Iterations=1000):
    N = y.shape[0]
    nh = max(h.shape)
    h = np.append(h, np.zeros((N - nh, 1)))
    H = np.fft.fft(h, axis=0)
    Y = np.fft.fft(y, axis=0)

    # Estimate noise using a moving average filter
    window_size = 5  # Define the size of the moving average window
    kernel = np.ones(window_size) / window_size
    smoothed_y = convolve(y.flatten(), kernel, mode='same')
    sigma = np.std(smoothed_y)  # Estimate noise as the standard deviation of the smoothed signal

    Phh = np.square(abs(H))
    sqrdtempnorm = ((((np.linalg.norm(y - np.mean(y), 2)**2) - (N - 1) * (sigma**2)))/(np.linalg.norm(h, 1))**2)
    Nf = (sigma**2) * N
    tempreg = Nf / sqrdtempnorm
    Pxx0 = np.square(abs(np.multiply(Y, (np.divide(np.conj(H), (Phh + N * tempreg))))))
    Pxx = Pxx0
    Sf = Pxx.reshape(-1, 1)

    for i in range(Iterations):
        M = np.divide(np.multiply(np.multiply(np.conjugate(H), Pxx), Y), np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
        PxxY = np.divide(np.multiply(Pxx, Nf), np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
        Pxx = np.add(PxxY, np.square(abs(M)))
        Sf = np.concatenate((Sf, Pxx.reshape(-1, 1)), axis=1)

    dSf = np.diff(Sf, 1, 1)
    dSfmse = np.mean(np.square(dSf), axis=1)
    
    # Finding knee point for optimal iteration
    idm = np.argmin(dSfmse)
    ratio = (np.abs(dSfmse[np.argmax(dSfmse)] - dSfmse[idm]) / 
             (np.abs(np.max(dSfmse) - np.min(dSfmse))))
    
    if ratio > 0.5:
        id0 = idm 
    else:
        id0 = np.argmax(dSfmse) 

    Pxx = Sf[:, id0 + 1]
    WienerFilterEst = np.divide(np.multiply(np.conj(H), Pxx), 
                                 np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
    
    return np.real(np.fft.ifft(np.multiply(WienerFilterEst, Y)))


# import rsHRF_toolbox.pyyawt as pyyawt
# # import pywt
# import numpy as np 
# import rsHRF_toolbox.knee as knee


# def rsHRF_iterative_wiener_deconv(y, h, Iterations=1000):
#     N            = y.shape[0]
#     nh           = max(h.shape)
#     h            = np.append(h, np.zeros((N - nh, 1)))
#     H            = np.fft.fft(h, axis=0)
#     Y            = np.fft.fft(y, axis=0)
#     [c ,l]       = pyyawt.wavedec(abs(y), 1, 'db2')
#     sigma        = pyyawt.wnoisest(c, l, 1)
#     Phh          = np.square(abs(H))
#     sqrdtempnorm = ((((np.linalg.norm(y-np.mean(y), 2)**2) - (N-1)*(sigma**2)))/(np.linalg.norm(h,1))**2)
#     Nf           = (sigma**2)*N
#     tempreg      = Nf/sqrdtempnorm
#     Pxx0         = np.square(abs(np.multiply(Y, (np.divide(np.conj(H), (Phh + N*tempreg))))))
#     Pxx          = Pxx0
#     Sf           = Pxx.reshape(-1, 1)
#     for i in range(0, Iterations):
#         M           = np.divide(np.multiply(np.multiply(np.conjugate(H), Pxx), Y), np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
#         PxxY        = np.divide(np.multiply(Pxx, Nf), np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
#         Pxx         = np.add(PxxY, np.square(abs(M)))
#         Sf          = np.concatenate((Sf, Pxx.reshape(-1, 1)), axis = 1)
#     dSf             = np.diff(Sf, 1, 1)
#     dSfmse          = np.mean(np.square(dSf), axis=1)
#     _, idx          = knee.knee_pt(dSfmse)
#     idm             = np.argmin(dSfmse)
#     ratio           = np.abs(dSfmse[idx] - dSfmse[idm])/(np.abs(np.max(dSfmse) - np.min(dSfmse)))
#     if ratio > 0.5:
#         id0 = idm 
#     else:
#         id0 = idx 
#     Pxx             = Sf[:,id0+1]
#     WienerFilterEst = np.divide(np.multiply(np.conj(H), Pxx), np.add(np.multiply(np.square(abs(H)), Pxx), Nf))
#     return np.real(np.fft.ifft(np.multiply(WienerFilterEst, Y)))



# coeffs = pywt.wavedec(abs(y), 'db1')  # Decompose using Daubechies wavelet
# sigma = pywt.threshold(coeffs, threshold='soft')  # Apply thresholding

# sigma = np.std(coeffs[-1])  # Example: standard deviation of the last coefficient

# Apply soft thresholding with a defined threshold value
# threshold_value = sigma  # You can adjust this based on your needs
# thresholded_coeffs = [pywt.threshold(c, threshold_value, mode='soft') for c in coeffs]
