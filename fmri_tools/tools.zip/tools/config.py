import os, json
import numpy as np

# def print_config_file(config, process='initial'):
#     return

# def check_files_exists(config, process='initial'):
#     return

# def load_config(config, process='init'):

#     if process =='init':
#         config

#     return

# def create_config(input_parameters):

import os, json
import numpy as np
from pathlib import Path
import os
from tools.atlases import load_atlas
from typing import Dict, Union, List
import os

def decompose_filename(fname, exts=('.nii', '.nii.gz')):
    fnamein_list = fname.split(os.path.sep)
    pardir = fnamein_list[-2] if len(fnamein_list) > 1 else '.'
    path = os.path.join(*fnamein_list[:-1]) if len(fnamein_list) > 1 else '.'
    fname = fnamein_list[-1]
    for ext in exts:
        if fname.endswith(ext):
            ext_file = ext
            fname = fname.replace(ext, '')
    return path, pardir, fname, ext_file


def put_inputs_into_format(input_parameters, config, subject_data_template):

    # complete input parameters with defaults
    # populate general config parameteres from input_parameters
    for key, value in subject_data_template.items():
        if key not in input_parameters:
            input_parameters[key] = value

    if not isinstance(input_parameters['fin-func'], list):
        input_parameters['fin-func'] = [input_parameters['fin-func']]

    N_funcfiles = len(input_parameters['fin-func'])

    if not isinstance(input_parameters['TR0'], list):
        input_parameters['TR0'] = N_funcfiles * [input_parameters['TR0']]

    if input_parameters['fin-anat'] is not None:
        if not isinstance(input_parameters['fin-anat'], list):
            input_parameters['fin-anat'] = N_funcfiles * [input_parameters['fin-anat']]

    if input_parameters['fin-mask'] is not None:
        if not isinstance(input_parameters['fin-mask'], list):
            input_parameters['fin-mask'] = N_funcfiles * [input_parameters['fin-mask']]

    if input_parameters['flag-use-parcellation-as-mask']:
        if input_parameters['parcellation-method'] is None:
            raise ValueError(f"""
                            If 'flag-use-parcellation-as-mask' is True, 
                            you must provide a valid 'parcellation-method'.
                            Valid methods: 
                                    'aal'"""
                            )
        input_parameters['fin-mask'] = N_funcfiles * [load_atlas(input_parameters['parcellation-method'])['maps']]

    path_output = config['path-output']

    subject_data = N_funcfiles * [dict(subject_data_template)]
    for i in range(N_funcfiles):
        subject_data[i]['fin-func'] = input_parameters['fin-func'][i]
        subject_data[i]['fin-anat'] = input_parameters['fin-anat'][i]
        subject_data[i]['fin-mask'] = input_parameters['fin-mask'][i]
        subject_data[i]['TR0'] = input_parameters['TR0'][i]
        

        path, pardir, funcfname, ext_file = decompose_filename(subject_data[i]['fin-func'])

        subject_data[i]['file-pattrn'] = funcfname
        subject_data[i]['pardir'] = pardir

        subj_path = os.path.join(path_output, pardir)
        if not os.path.exists(subj_path):
            os.mkdir(subj_path)

        subject_data[i]['subj-path'] = subj_path

        # proprocessing files

        foutprep = os.path.join(subj_path, f'prep-{funcfname}.nii.gz')
        foutmask = os.path.join(subj_path, f'prep-{funcfname}.nii.gz')
        foutanat = os.path.join(subj_path, f'prep-{funcfname}.nii.gz')

        subject_data[i]['fout-prep-func'] = foutprep
        subject_data[i]['fout-prep-anat'] = foutanat
        subject_data[i]['fout-prep-mask'] = foutmask

    return subject_data

# subject_data_template = {
#     'subj-path': None,
#     'file-pattrn': None,
#     'fin-func': None,
#     'fin-anat': None, 
#     'fin-mask': None,
#     'TR0': None,
#     'fout-prep-func': None,
#     'fout-prep-anat': None,
#     'fout-prep-mask': None,
#     'mask-for-deconv': None,
#     'mask-for-events': None
#     }




def check_inputfiles_exists(input_filenames, exts):
    flag_exists = True
    flag_ext_supported = True
    for full_fname in input_filenames:

        flag_ext_ = False
        for ext in exts:
            if full_fname.endswith(ext):
                flag_ext_ = True
        if not flag_ext_:
            print(f'{full_fname} -> extension not supported')
            flag_ext_supported = False

        if not os.path.exists(full_fname): 
            flag_exists = False
            print(f'{full_fname} -> exists = {flag_exists}')
    
    return flag_exists, flag_ext_supported

def check_bids(pathtocheck):
    return True


def check_mandatory_inputs(input_parameters: Dict[str, Union[str, float, int, List, None]]) -> bool:

    mandatory_params = {
        "'fin-func' or 'path-bids'": "full filename, list of full filenames or path of BIDS to functional MRI datasets",
        'TR0': "time of repetition in seconds",
        'regx': "regularization parameter for estimating x",
        'regh': "regularization parameter for estimating the HRF"
        }

    missing_params = [param for param, desc in mandatory_params.items() 
                      if param not in input_parameters or input_parameters[param] is None]

    if missing_params:
        if 'fin-func' in missing_params and os.path.exists(input_parameters.get('path-bids', '')):
            missing_params.remove('fin-func')

    if missing_params:
        print("\nThe following input parameters are mandatory:")
        for param in missing_params:
            print(f"'{param}' ({type(mandatory_params[param]).__name__}): {mandatory_params[param]}")
        return False

    return True



    # input_parameters = {
    #     'fin-func': 'swbold.nii.gz', 'TR0': 2, 'regx': 0.3, 'regh': 0.3,
    #     'path-fin-func': os.path.join(str(Path.home()), 'data', 'voice-non-voice'),
    #     'flag-use-parcellation-as-mask': True,
    #     'parcellation-method': 'aal',
    #     'n-first-scans-to-eliminate': 5}
    # 'regx': np.round(np.linspace(0.1, 0.5, 5),2),
    # 'regh': np.round(np.linspace(0.1, 0.5, 5),2),
    # 'rel_height_list' : np.round(np.linspace(0.1, 0.5, 10),2),
    # none_check = {key: config[key] is None for key in keys_mandatory}
    # print(none_check)

    
#     if not isinstance(input_parameters, dict):
#         print(f"\nThe input parameters must be a dictionary with at least the following parameters:\n{msg_}")
#         return None

#     keys_mandatory = ['fin-func', 'TR0', 'regx', 'regh']
#     for km in keys_mandatory:
#         if km not in input_parameters:
#             print(f"\nThe following input parameters are mandatory:\n{msg_}")
#             return None

#     config = {
#         'fin-func': None, 'TR0': None, 'regx': None, 'regh': None,
#         'exp-id': None, 'path-output': '.',
#         'fin-types': ('.nii.gz', '.nii'),
#         'HRF-duration-sec': 20, 'n-first-scans-to-eliminate': 0, 'TR': 0.5,
#         'parallel': True, 'n_jobs': -1, 'verbose': True,
#         'fin-anat': None, 'fin-mask': None,
#         'path-fin-func': '.', 'path-fin-anat': None, 'path-fin-mask': None,
#         'parcellation-method': None, 'flag-use-parcellation-as-mask': False,
#         'mask-for-deconv': None, 'deconv-hrf-mode': 'fixed-hrf-spm',
#         'mask-for-events': None, 'rel_height_list': [0.2, 0.3, 0.4, 0.5]}

#     config.update(input_parameters)

#     ### checking that the regularization parameters are correctly provided
#     if config['regx'] is None or config['regh'] is None:
#         reg_parameters_ok = False
#     elif isinstance(config['regx'], (float, int)) and isinstance(config['regh'], (float, int)):
#         config['regx'] = [config['regx']]
#         config['regh'] = [config['regh']]
#         reg_parameters_ok = True
#     elif hasattr(config['regx'], '__len__') and hasattr(config['regh'], '__len__') and len(config['regx']) == len(config['regh']):
#         reg_parameters_ok = True
#     else:
#         reg_parameters_ok = False

#     if not reg_parameters_ok:
#         print(config['regx'], config['regh'])
#         raise ValueError("regx and regh must be either two numbers or lists/arrays of the same length.")

#     flag_check_inputs = False
#     flag_ext = False
#     # print(os.path.splitext(config['fin-func']))
#     for ext in config['fin-types']:
#         if config['fin-func'].endswith(ext):
#             if config['exp-id'] is None:
#                 config['exp-id'] = config['fin-func'].replace(ext, '')
#             flag_ext = True
#     if not flag_ext and flag_check_inputs:
#         raise ValueError(f"Input file type is not supported. Provide a file within the types {config['fin-types']}.")

#     config['fin-func'] = os.path.join(config['path-fin-func'], 
#                                     config['fin-func'])
#     if not os.path.exists(config['fin-func']) and flag_check_inputs:
#         raise FileNotFoundError(f"The file '{config['fin-func']}' does not exist.")

#     if config['fin-anat'] is not None:
#         config['fin-anat'] = os.path.join(config['path-fin-anat'], 
#                                         config['fin-anat'])
#         if not os.path.exists(config['fin-anat']) and flag_check_inputs:
#             raise FileNotFoundError(f"The file '{config['fin-anat']}' does not exist.")

#     ########## determining wich mask to use
#     if config['flag-use-parcellation-as-mask']:
#         if config['parcellation-method'] is None:
#             raise ValueError(f"You must provide a parcellation method. Change config['parcellation-method'].")
#     elif config['fin-mask'] is not None: 
#         config['fin-mask'] = os.path.join(config['path-fin-mask'], 
#                                         config['fin-mask'])
#         if not os.path.exists(config['fin-mask']) and flag_check_inputs:
#             raise FileNotFoundError(f"The file {config['fin-mask']} does not exist.")

#     ########## output directory
#     config['path-output'] = os.path.join(config['path-output'], 
#                                         'output-'+config['exp-id'])
#     if not os.path.exists(config['path-output']):
#         os.mkdir(config['path-output'])


#     ########## some output filenames
#     config['fout-preproc-func'] = os.path.join(
#         config['path-output'],
#         f"prep-func-{config['exp-id']}.nii.gz"
#         )
#     config['fout-preproc-anat'] = os.path.join(
#         config['path-output'],
#         f"prep-anat-{config['exp-id']}.nii.gz"
#         )
#     config['fout-preproc-mask'] = os.path.join(
#         config['path-output'],
#         f"mask-{config['exp-id']}.nii.gz"
#         )
#     if config['mask-for-deconv'] is None:
#         config['mask-for-deconv'] = config['fout-preproc-mask']
#     if config['mask-for-events'] is None:
#         config['mask-for-events'] = config['fout-preproc-mask']


#     config['fin-deconv'] = config['fout-preproc-func']

#     config['fout-deconvx-0'] = []
#     config['fout-deconvx-bias-0'] = []
#     config['fout-deconvh-0'] = []
#     config['fout-deconvh-bias-0'] = []
#     for regx, regh in zip(config['regx'], config['regh']):
#         regx_str = str(regx).replace('.', 'p')
#         regh_str = str(regh).replace('.', 'p')
#         config['fout-deconvx-0'].append(
#             os.path.join(config['path-output'], f'deconvx0-{regx_str}.nii.gz'))
#         config['fout-deconvx-bias-0'].append(
#             os.path.join(config['path-output'], f'deconvx0-bias-{regx_str}.nii.gz'))
#         config['fout-deconvh-0'].append(
#             os.path.join(config['path-output'], f'deconvh0-{regh_str}.nii.gz'))
#         config['fout-deconvh-bias-0'].append(
#             os.path.join(config['path-output'], f'deconvh0-bias-{regh_str}.nii.gz'))

#     ############## determining inputs files for event detection
#     def create_filename_for_events(fname):
#         exts = ['.nii.gz', '.nii']
#         if os.path.sep in fname:
#             fname_list = fname.split(os.path.sep)
#         fname = fname_list[-1]
#         for ext in exts:
#             if fname.endswith(ext):
#                 fname = fname.replace(ext, '.npz')
#                 fname = 'ev-'+fname
#         fname_list[-1] = fname
#         return os.path.sep.join( fname_list )

#     config['fin-events'] = [config['fout-preproc-func']]
#     config['fout-events'] = [create_filename_for_events(
#         config['fout-preproc-func']
#         )]

#     for fname in config['fout-deconvx-0']:
#         config['fin-events'].append(fname)
#         config['fout-events'].append(
#             create_filename_for_events(fname))
#     # for f1,f2 in zip(config['fin-events'], config['fout-events']):
#     #     print(f1)
#     #     print('\t\t', f2)

#     for k in config:
#         if isinstance(config[k], np.ndarray):
#             config[k] = config[k].tolist()

#     with open(f"{os.path.join(config['path-output'], config['exp-id'])}.json", "w") as outfile:
#         json.dump(config, 
#                 outfile, 
#                 #   separators=(',', ':'), 
#                 sort_keys=False, 
#                 indent=4)
#         print(f"Configuration file saved in {os.path.join(config['path-output'], config['exp-id'])}.json")
        
#     return config

# if __name__ == "__main__":


#     from pathlib import Path

#     input_parameters = {
#         'fin-func': 'swbold.nii.gz', 'TR0': 2, 'regx': 0.3, 'regh': 0.3,
#         'path-fin-func': os.path.join(str(Path.home()), 'data', 'voice-non-voice'),
#         'flag-use-parcellation-as-mask': True,
#         'parcellation-method': 'aal',
#         'n-first-scans-to-eliminate': 5}

#     input_parameters = []
#     config = create_configuration_file(input_parameters)

#     # input_parameters = {
#     #     'fin-func': 'swbold.nii.gz', 'TR0': 2, 'regx': 0.3, 'regh': 0.3,
#     #     'path-fin-func': os.path.join(str(Path.home()), 'data', 'voice-non-voice'),
#     #     'flag-use-parcellation-as-mask': True,
#     #     'parcellation-method': 'aal',
#     #     'n-first-scans-to-eliminate': 5}

# #######################################################
