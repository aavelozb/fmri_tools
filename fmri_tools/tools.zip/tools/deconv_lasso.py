import os, sys, shutil, time
import numpy as np
import matplotlib.pyplot as plt
from math import sqrt
from scipy import signal, interpolate, linalg
from scipy.linalg import toeplitz, solve_triangular
from joblib import Parallel, delayed, cpu_count, Memory
from tqdm import tqdm

# imports from local files
from tools.misc import hrf_func
# from data_manipulation import map_unmasked3d_to_maskedidx




######################### function to perform deconvolution Tikhonov method
# The implementation logic is that it receives a matrix with signals Y 



##################### X deconvolution

### case single HRF
import numpy as np
from scipy import linalg
from scipy.linalg import toeplitz
from math import sqrt
from joblib import Parallel, delayed
from tqdm import tqdm
import time
from sklearn.linear_model import Lasso
import dask.array as da
# from memory_profiler import profile
# @profile


def deconv_x_lasso_single_hrf(yi, Hi, model):
    model.fit(Hi, yi)
    Xest, Xest_bias = model.coef_[1:], model.coef_[0]
    return Xest, Xest_bias

def deconv_x_lasso_voxelwise_hrf(yi, hi, model, T):
    Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
    # Y = da.from_array(Y, chunks='auto')
    # Y_df = Y.compute()
    # model = Lasso(alpha=lambda_xi)
    model.fit(Hi, yi)
    Xest, Xest_bias = model.coef_[1:], model.coef_[0]
    return Xest, Xest_bias




def deconv_x_lasso(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True):

    T, N = Y.shape
    Th = H.shape[0]
    Nhrfs = H.shape[1] if H.ndim > 1 else 1
    
    if verbose:
        start_time = time.time()

    if Nhrfs == 1:
        print(30*'-' + ' X estimation - LASSO single HRF')
        H_padded = np.pad(H, (0, T - Th), 'constant') if T > Th else H
        Hi = np.column_stack((np.ones(T), toeplitz(H_padded, np.zeros(T))))
        p = ({'yi': Y[:, s], 'Hi': Hi, 'model': Lasso(alpha=lambdax)} for s in range(Y.shape[1]))
        decfun = deconv_x_lasso_single_hrf
        # decfun = ira_fista
        # decfun = fista_optimized

        # Y = da.from_array(Y, chunks='auto')
        # Y_df = Y.compute()
        # model = Lasso(alpha=lambdax)
        # model.fit(Hi, Y_df)
        # # Print coefficients
        # X = model.coef_.T
        # Xest, Xest_bias = X[1:,:], X[0,:]
        # return Xest, Xest_bias
    else:
        H_padded = np.pad(H, ((0, T - Th), (0, 0)), 'constant') if T > Th else H
        p = ({'yi': Y[:, s], 'hi': H_padded[:, s], 'lambda_xi': lambdax, 'T': T} for s in range(Y.shape[1]))
        decfun = deconv_x_lasso_voxelwise_hrf


    if parallel:
        results = Parallel(n_jobs=n_jobs)(delayed(decfun)(**params) for params in tqdm(p, total=N, desc='(parallel processing)'))
    else:
        results = list(map(lambda params: decfun(**params), tqdm(p, total=N, desc='(parallel processing: off)')))

    if verbose:
        print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    Xest, Xest_bias = zip(*results)
    return np.array(Xest).T, np.array(Xest_bias)










import torch
import torch.nn as nn
import torch.optim as optim

class LassoPyT(nn.Module):
    def __init__(self, input_size, n_signals=1):
        super(LassoPyT, self).__init__()
        self.linear = nn.Linear(input_size, n_signals, bias=False)
    
    def forward(self, x):
        return self.linear(x)

def lasso_regression(X, y, lr=0.005, max_iter=2000, alpha=0.1):
    model = LassoPyT(X.shape[1])
    criterion = nn.MSELoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    for _ in range(max_iter):
        optimizer.zero_grad()
        output = model(X)
        loss = criterion(output, y)
        l1_loss = alpha * torch.norm(model.linear.weight, p=1)
        total_loss = loss + l1_loss
        total_loss.backward()
        optimizer.step()
    
    return model.linear.weight.detach()



if __name__ == "__main__":

    from tools.misc import hrf_func
    import nibabel as nib
    from nilearn.masking import apply_mask, unmask
    import dask.array as da


    Y_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz")
    mask_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz")
    Y = apply_mask(Y_img, mask_img)    

    T, N = Y.shape
    TR = 0.5
    Th = 40
    isignal = 100
    timeline = np.arange(T) * TR
    y = Y[:, isignal]

    delay_h0, disp_h0 = 3, 1
    H = hrf_func(timeline[:Th], delay=delay_h0, disp=disp_h0)

    H = np.pad(H, (0, T - Th), 'constant') if T > Th else H
    H = np.column_stack((np.ones(T), toeplitz(H, np.zeros(T))))
    print(H.shape)

    lambdax = 0.001
    model = Lasso(alpha=lambdax)
    from scipy import sparse
    H_sparse = sparse.csr_matrix(H)

    # t0 = time.time()
    # model.fit(H, Y[:,:1])
    # print('etime', time.time()-t0)
 
    # t0 = time.time()
    # model.fit(H_sparse, Y[:,:1])
    # print('etime', time.time()-t0)

    # t0 = time.time()
    # w = lasso_regression(H, Y[:,:1])
    # print('etime', time.time()-t0)

    Ht = torch.from_numpy(H).float()
    yt = torch.from_numpy(Y).float()
    # Yt = torch.from_numpy(Y[:,isignal])
    model = LassoPyT(Ht.shape[1], Y.shape[1])
    # w = lasso_regression(Ht, Y[:,isignal])
    
    lr=0.005
    max_iter=2000
    alpha=2
    criterion = nn.MSELoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    for it in range(max_iter):
        print(it)
        optimizer.zero_grad()
        output = model(Ht)
        loss = criterion(output, yt) # .unsqueeze(1)
        l1_loss = alpha * torch.norm(model.linear.weight, p=1)
        total_loss = loss + l1_loss
        total_loss.backward()
        optimizer.step()
    
    w = model.linear.weight.detach().numpy()
    # return model.linear.weight.detach()

    w = w.T
    xest = w[1:, :]
    # xest, xest_bias = model.coef_[1:], model.coef_[0]

    plt.figure()
    plt.plot(timeline, Y[:,100])
    plt.plot(timeline, xest[:,100])
    plt.show()

    # H0 = np.column_stack(N * [h0])

    # print(Y.shape)
    # Y = da.from_array(Y.T, chunks='auto')
    # print(type(Y), Y.shape)
    # Y_df = Y.compute()
    # print(type(Y_df))


    # T = 1000
    # Th = 40
    # TR = 0.5
    # N = 10000

    # timeline = np.arange(T) * TR
    # x_true = np.zeros((T, N))
    # y = np.zeros((T, N))

    # x_true[100, :] = 1
    # x_true[700, :] = 1

    # h_true = hrf_func(timeline)
    # H_true = toeplitz(h_true, np.zeros(T))

    # for i in range(N):
    #     y[:, i] = H_true @ x_true[:, i]

    # # y = H_true @ x_true
    # # print(x_true.shape, y.shape, h_true.shape, H_true.shape)

    # h0 = hrf_func(timeline[:Th], delay=3, disp=1)
    # xest, xbias = deconv_x_fista(y, h0, lambdax=1, bias=True, parallel=True, n_jobs=-1, verbose=True)

    # # Y = y[:, np.newaxis]
    # # X = x_true[:, np.newaxis]
    # # hest, hbias = deconvh_tikhonov(Y, X, lambdah=0.5, Th=Th, bias=True, parallel=True, n_jobs=-1, verbose=True)

    # plt.figure(figsize=(12,6))
    # plt.plot(timeline, x_true[:, 0])
    # plt.plot(timeline, xest[:, 0])
    # plt.plot(timeline, y[:, 0])
    # # plt.figure()
    # # plt.plot(timeline[:Th], h_true[:Th])
    # # plt.plot(timeline[:Th], h0)
    # # plt.plot(timeline[:Th], hest.flatten())
    # # plt.figure(figsize=(12,6))
    # # plt.plot(costs)

    # plt.show()



# def deconv_x_ista_test(yi, hi, lambda_xi, T, tol=1e-6, maxit=5000):
#     Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
#     x_est = np.zeros(Hi.shape[1])
#     L = linalg.norm(Hi) ** 2 # Lipschitz constant
#     lambda_xiL = lambda_xi / L
#     cost, patience, max_patience = float('inf'), 0, 4
#     costs = []
#     for it in range(maxit):
#         x_est = x_est + np.dot(Hi.T, yi - Hi.dot(x_est)) / L
#         x_est = np.sign(x_est) * np.maximum(np.abs(x_est) - lambda_xiL, 0.)
#         cost0 = cost
#         cost = 0.5 * linalg.norm(Hi.dot(x_est) - yi) ** 2 + lambda_xi * linalg.norm(x_est, 1)
#         costs.append(cost)
#         if np.abs(cost-cost0) < tol:
#             patience += 1
#         if patience > max_patience:
#             break
#     return x_est[1:], x_est[0], costs