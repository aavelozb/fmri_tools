import os, sys, shutil, time
import numpy as np
import matplotlib.pyplot as plt
from math import sqrt
from scipy import signal, interpolate, linalg
from scipy.linalg import toeplitz, solve_triangular
from joblib import Parallel, delayed, cpu_count, Memory
from tqdm import tqdm

# imports from local files
from tools.misc import hrf_func
# from data_manipulation import map_unmasked3d_to_maskedidx




######################### function to perform deconvolution Tikhonov method
# The implementation logic is that it receives a matrix with signals Y 



##################### X deconvolution

### case single HRF
import numpy as np
from scipy import linalg
from scipy.linalg import toeplitz
from math import sqrt
from joblib import Parallel, delayed
from tqdm import tqdm
import time
from sklearn.linear_model import Lasso
import dask.array as da
# from memory_profiler import profile
# @profile


def deconv_x_lasso_single_hrf(yi, Hi, model):
    model.fit(Hi, yi)
    Xest, Xest_bias = model.coef_[1:], model.coef_[0]
    return Xest, Xest_bias

def deconv_x_lasso_voxelwise_hrf(yi, hi, model, T):
    Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
    # Y = da.from_array(Y, chunks='auto')
    # Y_df = Y.compute()
    # model = Lasso(alpha=lambda_xi)
    model.fit(Hi, yi)
    Xest, Xest_bias = model.coef_[1:], model.coef_[0]
    return Xest, Xest_bias




def deconv_x_lasso(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True):

    T, N = Y.shape
    Th = H.shape[0]
    Nhrfs = H.shape[1] if H.ndim > 1 else 1
    
    if verbose:
        start_time = time.time()

    if Nhrfs == 1:
        print(30*'-' + ' X estimation - LASSO single HRF')
        H_padded = np.pad(H, (0, T - Th), 'constant') if T > Th else H
        Hi = np.column_stack((np.ones(T), toeplitz(H_padded, np.zeros(T))))
        p = ({'yi': Y[:, s], 'Hi': Hi, 'model': Lasso(alpha=lambdax)} for s in range(Y.shape[1]))
        decfun = deconv_x_lasso_single_hrf
        # decfun = ira_fista
        # decfun = fista_optimized

        # Y = da.from_array(Y, chunks='auto')
        # Y_df = Y.compute()
        # model = Lasso(alpha=lambdax)
        # model.fit(Hi, Y_df)
        # # Print coefficients
        # X = model.coef_.T
        # Xest, Xest_bias = X[1:,:], X[0,:]
        # return Xest, Xest_bias
    else:
        H_padded = np.pad(H, ((0, T - Th), (0, 0)), 'constant') if T > Th else H
        p = ({'yi': Y[:, s], 'hi': H_padded[:, s], 'lambda_xi': lambdax, 'T': T} for s in range(Y.shape[1]))
        decfun = deconv_x_lasso_voxelwise_hrf


    if parallel:
        results = Parallel(n_jobs=n_jobs)(delayed(decfun)(**params) for params in tqdm(p, total=N, desc='(parallel processing)'))
    else:
        results = list(map(lambda params: decfun(**params), tqdm(p, total=N, desc='(parallel processing: off)')))

    if verbose:
        print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    Xest, Xest_bias = zip(*results)
    return np.array(Xest).T, np.array(Xest_bias)



# lambdax = 0.001
# model = Lasso(alpha=lambdax)
# from scipy import sparse
# H_sparse = sparse.csr_matrix(H)
# # t0 = time.time()
# # model.fit(H, Y[:,:1])
# # print('etime', time.time()-t0)

# # t0 = time.time()
# # model.fit(H_sparse, Y[:,:1])
# # print('etime', time.time()-t0)

# # t0 = time.time()
# # w = lasso_regression(H, Y[:,:1])
# # print('etime', time.time()-t0)

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import nibabel as nib
from nilearn.masking import apply_mask
from scipy.linalg import toeplitz
import matplotlib.pyplot as plt
from tools.misc import hrf_func

class LassoPyT(nn.Module):
    def __init__(self, input_size, n_signals=1):
        super(LassoPyT, self).__init__()
        self.linear = nn.Linear(input_size, n_signals, bias=False)
    
    def forward(self, x):
        return self.linear(x)

def load_and_preprocess_data(bold_path, mask_path):
    Y_img = nib.load(bold_path)
    mask_img = nib.load(mask_path)
    Y = apply_mask(Y_img, mask_img)
    return Y

def create_design_matrix(T, TR, Th, delay_h0, disp_h0):
    timeline = np.arange(T) * TR
    H = hrf_func(timeline[:Th], delay=delay_h0, disp=disp_h0)
    H = np.pad(H, (0, T - Th), 'constant') if T > Th else H
    return np.column_stack((np.ones(T), toeplitz(H, np.zeros(T))))

def train_lasso_model(H, Y, lr=0.005, max_iter=200, alpha=0.5):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    Ht = torch.from_numpy(H).float().to(device)
    yt = torch.from_numpy(Y).float().to(device)
    
    model = LassoPyT(Ht.shape[1], Y.shape[1]).to(device)
    criterion = nn.MSELoss(reduction='sum')
    optimizer = optim.Adam(model.parameters(), lr=lr)

    for it in range(max_iter):
        optimizer.zero_grad()
        output = model(Ht)
        loss = criterion(output, yt)
        l1_loss = alpha * torch.norm(model.linear.weight, p=1)
        total_loss = loss + l1_loss
        total_loss.backward()
        optimizer.step()

        if it % 100 == 0:
            print(f"Iteration {it}, Loss: {total_loss.item()}")

    return model.linear.weight.detach().cpu().numpy().T

# # Load and preprocess data
# Y = load_and_preprocess_data(
#     "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz",
#     "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
# )
# T, N = Y.shape

# ########### convolution in pytorch
# import torch
# import numpy as np
# import torch.nn.functional as F

# def convolve_pytorch(x, h):
#     T, Th = len(x), len(h)
#     if not isinstance(x, torch.Tensor):
#         x = torch.from_numpy(x).float()    
#     if not isinstance(h, torch.Tensor):
#         h = torch.from_numpy(h).float()    
#     x = x.view(1, 1, -1)  # Reshape to (1, 1, T)
#     h = h.flip(0).view(1, 1, -1)  # Flip and reshape to (1, 1, Th)
#     y = F.conv1d(x, h, padding=Th-1)[:, :, :T].squeeze()
#     return y.numpy()
    
# T = 1800
# x = np.zeros((T,))
# x[500] = 1
# Th = 40
# TR = 0.5
# timeline = np.arange(T) * TR
# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# y = np.convolve(x, h, mode='full')[:T]
# ypt = convolve_pytorch(x, h)
# plt.figure()
# plt.plot(timeline, y)
# plt.plot(timeline, ypt+0.5)
# plt.plot(timeline, x)
# plt.show()

# consider the following problem:

# y = h * x where * denotes convolution. h is length Th, x is of length T and y is of length T
# I want to estimate x using the Lasso

# \| y - h * x \|_2^2 + alpha \| x \|_1

# I want to implement it in pytorch using convolution operator

# def convolve_pytorch(x, h):
#     T, Th = len(x), len(h)
#     if not isinstance(x, torch.Tensor):
#         x = torch.from_numpy(x).float()    
#     if not isinstance(h, torch.Tensor):
#         h = torch.from_numpy(h).float()    
#     x = x.view(1, 1, -1)  # Reshape to (1, 1, T)
#     h = h.flip(0).view(1, 1, -1)  # Flip and reshape to (1, 1, Th)
#     y = F.conv1d(x, h, padding=Th-1)[:, :, :T].squeeze()
#     return y.numpy()
    
# Can implelemt this?


import torch
import torch.nn.functional as F
import numpy as np

def convolve_pytorch(x, h):
    T, Th = len(x), len(h)
    if not isinstance(x, torch.Tensor):
        x = torch.from_numpy(x).float()    
    if not isinstance(h, torch.Tensor):
        h = torch.from_numpy(h).float()    
    x = x.view(1, 1, -1)  # Reshape to (1, 1, T)
    h = h.flip(0).view(1, 1, -1)  # Flip and reshape to (1, 1, Th)
    y = F.conv1d(x, h, padding=Th-1)[:, :, :T].squeeze()
    return y

def lasso_loss(y, x, h, alpha):
    """
    Lasso loss function: ||y - h * x||_2^2 + alpha * ||x||_1

    Args:
        y (torch.Tensor): Observed signal of length T
        x (torch.Tensor): Estimated signal of length T
        h (torch.Tensor): Convolution kernel of length Th
        alpha (float): Regularization parameter

    Returns:
        torch.Tensor: Lasso loss value
    """
    # Perform convolution (h * x)
    y_pred = convolve_pytorch(x, h)
    l2_loss = torch.sum((y - y_pred) ** 2)
    l1_loss = alpha * torch.sum(torch.abs(x))
    return l2_loss + l1_loss

def estimate_x_lasso(y, h, alpha, num_iterations=1000, learning_rate=0.01):
    """
    Estimate x using Lasso optimization

    Args:
        y (torch.Tensor): Observed signal of length T
        h (torch.Tensor): Convolution kernel of length Th
        alpha (float): Regularization parameter
        num_iterations (int): Number of optimization iterations
        learning_rate (float): Learning rate for optimization

    Returns:
        torch.Tensor: Estimated x
    """
    T = len(y)
    x = torch.zeros(T, requires_grad=True)
    optimizer = torch.optim.Adam([x], lr=learning_rate)
    for _ in range(num_iterations):
        optimizer.zero_grad()
        loss = lasso_loss(y, x, h, alpha)
        loss.backward()
        optimizer.step()
    return x.detach()

# Example usage
# T = 1800
# x = np.zeros((T,))
# x[500] = 1
# Th = 40
# TR = 0.5
# timeline = np.arange(T) * TR
# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# y = np.convolve(x, h, mode='full')[:T]
# y = torch.from_numpy(y).float() 
# h = torch.from_numpy(h).float() 
# alpha = 0.5
# estimated_x = estimate_x_lasso(y, h, alpha)


# Load and preprocess data
# Y = load_and_preprocess_data(
#     "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz",
#     "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
# )
# T, N = Y.shape
# Th = 40
# TR = 0.5
# timeline = np.arange(T) * TR
# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# y = Y[:,100]
# y = torch.from_numpy(y).float() 
# h = torch.from_numpy(h).float() 
# alpha = 0.5
# estimated_x = estimate_x_lasso(y, h, alpha)
# print(f"Estimated x shape: {estimated_x.shape}")
# # plt.figure()
# # plt.plot(timeline, y)
# # plt.plot(timeline, estimated_x)
# # plt.show()


################
import torch
import torch.nn.functional as F
import numpy as np

def convolve_pytorch_batch(X, H):
    """
    Perform batch convolution for multiple signals and kernels.
    
    Args:
        X (torch.Tensor): Input signals of shape (N, T)
        H (torch.Tensor): Convolution kernels of shape (Th, N)
    
    Returns:
        torch.Tensor: Convolved signals of shape (N, T)
    """
    N, T = X.shape
    Th, _ = H.shape
    X = X.unsqueeze(0)  # Shape: (1, N, T), input shape for grouped convolution
    H = H.t().unsqueeze(1)  # Shape: (N, 1, Th), batch convolution
    H = H.flip(2)
    Y = F.conv1d(X, H, padding=Th-1, groups=N)[:, :, :T].squeeze().t()  # Shape: (T, N)
    return Y

def lasso_loss_batch(Y, X, H, alpha):
    """
    Batch Lasso loss function: sum(||y - h * x||_2^2) + alpha * sum(||x||_1)
    
    Args:
        Y (torch.Tensor): Observed signals of shape (N, T)
        X (torch.Tensor): Estimated signals of shape (N, T)
        H (torch.Tensor): Convolution kernels of shape (Th, N)
        alpha (float): Regularization parameter
    
    Returns:
        torch.Tensor: Lasso loss value
    """
    Y_pred = convolve_pytorch_batch(X, H)
    l2_loss = torch.sum((Y - Y_pred) ** 2)
    l1_loss = alpha * torch.sum(torch.abs(X))
    return l2_loss + l1_loss

def estimate_x_lasso_batch(Y, H, alpha, num_iterations=30, learning_rate=0.01):
    """
    Estimate X using batch Lasso optimization
    
    Args:
        Y (torch.Tensor): Observed signals of shape (N, T)
        H (torch.Tensor): Convolution kernels of shape (Th, N)
        alpha (float): Regularization parameter
        num_iterations (int): Number of optimization iterations
        learning_rate (float): Learning rate for optimization
    
    Returns:
        torch.Tensor: Estimated X of shape (N, T)
    """
    T, N = Y.shape
    X = torch.zeros(N, T, requires_grad=True)
    optimizer = torch.optim.Adam([X], lr=learning_rate)
    
    for it in range(num_iterations):
        print(it)
        optimizer.zero_grad()
        loss = lasso_loss_batch(Y, X, H, alpha)
        loss.backward()
        optimizer.step()
    
    return X.detach()

# ############test
# # T, N = Y.shape
# T, N = 1280, 200
# Th = 40
# TR = 0.5
# timeline = np.arange(T) * TR
# x = np.zeros(T)
# x[50] = 1
# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# y = np.convolve(x, h, mode='full')[:T]
# H = np.column_stack(N*[h]) # (40, 23238)
# Y = np.column_stack(N*[y]) # (T, 23238)
# Y = torch.from_numpy(Y).float()
# H = torch.from_numpy(H).float()
# Xest = estimate_x_lasso_batch(Y, H, alpha=0.05)


Y = load_and_preprocess_data(
    "results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz",
    "results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz"
)
Y = Y[:,:2000]
T, N = Y.shape
Th = 40
TR = 0.5
timeline = np.arange(T) * TR
h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
H = np.column_stack(N*[h]) # (40, 23238)
Y = torch.from_numpy(Y).float()
H = torch.from_numpy(H).float()
Xest = estimate_x_lasso_batch(Y, H, alpha=5, num_iterations=1000, learning_rate=0.01)



# y = Y[:,100]
# y = torch.from_numpy(y).float() 
# h = torch.from_numpy(h).float() 
# alpha = 0.5
# estimated_x = estimate_x_lasso(y, h, alpha)
# print(f"Estimated x shape: {estimated_x.shape}")
# # plt.figure()
# # plt.plot(timeline, y)
# # plt.plot(timeline, estimated_x)
# # plt.show()




# X = X.t().unsqueeze(1)  # Shape: (N, 1, T), batch convolution
# H = H.t().unsqueeze(1)  # Shape: (N, 1, Th), batch convolution
# H = H.flip(2)  # Flip the kernels for convolution
# X = X.view(1, N, 1, T)  # Shape: (1, N, 1, T), input shape for grouped convolution
# Y = F.conv1d(X.squeeze(2), H, padding=Th-1, groups=N)[:, :, :T].squeeze().t()  # Shape: (T, N)

# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# H = np.column_stack(N*[h]) # (40, 23238)
# H = torch.from_numpy(H).float()


# print(Y.shape, H.shape)


Ynp = Y.numpy()
Xnp = Xest.numpy().T
print(Xnp.shape)

plt.figure(figsize=(12, 6))
plt.plot(timeline, Ynp[:, 100], label='Convolved Signal')
plt.plot(timeline, Xnp[:, 100], label='Original Signal')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.title('Convolution Result for First Signal')
plt.legend()
plt.show()





# # Reshape Y back to (N, T)
# Y = Y.view(N, T)

# print("X shape:", X.shape)
# print("H shape:", H.shape)
# print("Y shape:", Y.shape)



# estimated_X = estimate_x_lasso_batch(Y, H, alpha)
# print(f"Estimated X shape: {estimated_X.shape}")

# # Plotting for a single signal (e.g., the first one)
# plt.figure()
# plt.plot(timeline, Y[0].numpy(), label='Observed')
# plt.plot(timeline, estimated_X[0].numpy(), label='Estimated')
# plt.legend()
# plt.show()


# Now consider that I have a set of signals stored of the columns of Y. 
# Each one has their own corresponding kernel on the columns of H.
# Consider this:

# T, N = Y.shape
# Th = 40
# TR = 0.5
# timeline = np.arange(T) * TR
# h = hrf_func(timeline[:Th])#, delay=delay_h0, disp=disp_h0)
# H = np.column_stack(N*[h]) # (40, 23238)
# Y = torch.from_numpy(Y).float() 
# H = torch.from_numpy(H).float() 
# In this regard, this is a set of N independent lasso problems.
# Can adapt this code to solve this based on this code?

# import torch
# import torch.nn.functional as F
# import numpy as np

# def convolve_pytorch(x, h):
#     T, Th = len(x), len(h)
#     if not isinstance(x, torch.Tensor):
#         x = torch.from_numpy(x).float()    
#     if not isinstance(h, torch.Tensor):
#         h = torch.from_numpy(h).float()    
#     x = x.view(1, 1, -1)  # Reshape to (1, 1, T)
#     h = h.flip(0).view(1, 1, -1)  # Flip and reshape to (1, 1, Th)
#     y = F.conv1d(x, h, padding=Th-1)[:, :, :T].squeeze()
#     return y

# def lasso_loss(y, x, h, alpha):
#     """
#     Lasso loss function: ||y - h * x||_2^2 + alpha * ||x||_1

#     Args:
#         y (torch.Tensor): Observed signal of length T
#         x (torch.Tensor): Estimated signal of length T
#         h (torch.Tensor): Convolution kernel of length Th
#         alpha (float): Regularization parameter

#     Returns:
#         torch.Tensor: Lasso loss value
#     """
#     # Perform convolution (h * x)
#     y_pred = convolve_pytorch(x, h)
#     l2_loss = torch.sum((y - y_pred) ** 2)
#     l1_loss = alpha * torch.sum(torch.abs(x))
#     return l2_loss + l1_loss

# def estimate_x_lasso(y, h, alpha, num_iterations=1000, learning_rate=0.01):
#     """
#     Estimate x using Lasso optimization

#     Args:
#         y (torch.Tensor): Observed signal of length T
#         h (torch.Tensor): Convolution kernel of length Th
#         alpha (float): Regularization parameter
#         num_iterations (int): Number of optimization iterations
#         learning_rate (float): Learning rate for optimization

#     Returns:
#         torch.Tensor: Estimated x
#     """
#     T = len(y)
#     x = torch.zeros(T, requires_grad=True)
#     optimizer = torch.optim.Adam([x], lr=learning_rate)
#     for _ in range(num_iterations):
#         optimizer.zero_grad()
#         loss = lasso_loss(y, x, h, alpha)
#         loss.backward()
#         optimizer.step()
#     return x.detach()


# alpha = 0.5
# estimated_x = estimate_x_lasso(y, h, alpha)
# print(f"Estimated x shape: {estimated_x.shape}")
# plt.figure()
# plt.plot(timeline, y)
# plt.plot(timeline, estimated_x)
# plt.show()



# # Create design matrix
# H = create_design_matrix(T, TR=0.5, Th=40, delay_h0=3, disp_h0=1)
# print(f"Design matrix shape: {H.shape}")

# # Train Lasso model
# w = train_lasso_model(H, Y)

# # Extract results
# xest = w[1:, :]

# # Plot results
# timeline = np.arange(T) * 0.5
# plt.figure()
# plt.plot(timeline, Y[:, 100], label='Original')
# plt.plot(timeline, xest[:, 100], label='Estimated')
# plt.legend()
# plt.show()



# import torch
# import torch.nn as nn
# import torch.optim as optim
# from torch.utils.data import TensorDataset, DataLoader

# class LassoModel(nn.Module):
#     def __init__(self, T):
#         super(LassoModel, self).__init__()
#         self.weights = nn.Parameter(torch.zeros(T))
    
#     def forward(self, H):
#         return torch.conv1d(self.weights.unsqueeze(0).unsqueeze(0), H.unsqueeze(0), padding='same').squeeze()

# def solve_lasso_for_columns_pytorch(H, Y, alpha=1.0, num_epochs=1000, batch_size=32, learning_rate=0.01):
#     device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#     Th, N = H.shape
#     T, _ = Y.shape
    
#     # Pad H to match the length of Y
#     H_padded = torch.nn.functional.pad(torch.from_numpy(H).float(), (0, 0, 0, T - Th))
#     Y_tensor = torch.from_numpy(Y).float()
    
#     # Move tensors to the selected device
#     H_padded = H_padded.to(device)
#     Y_tensor = Y_tensor.to(device)
    
#     # Create DataLoader
#     dataset = TensorDataset(H_padded.t(), Y_tensor.t())
#     dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False)
    
#     # Initialize model and optimizer
#     model = LassoModel(T).to(device)
#     optimizer = optim.Adam(model.parameters(), lr=learning_rate)
#     criterion = nn.MSELoss()
    
#     # Training loop
#     for epoch in range(num_epochs):
#         for H_batch, Y_batch in dataloader:
#             optimizer.zero_grad()
#             Y_pred = model(H_batch)
#             loss = criterion(Y_pred, Y_batch) + alpha * torch.norm(model.weights, 1)
#             loss.backward()
#             optimizer.step()
        
#         if (epoch + 1) % 100 == 0:
#             print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')
    
#     # Collect results
#     X_est = model.weights.detach().cpu().numpy()
    
#     return X_est

# # Example usage:
# # Th, N = 40, 1000  # Example dimensions
# # T = 200  # Example T > Th
# # H = np.random.randn(Th, N)  # Random H matrix
# # Y = np.random.randn(T, N)   # Random Y matrix

# # X_estimated = solve_lasso_for_columns_pytorch(H, Y, alpha=0.1)




# import torch
# import torch.nn as nn
# import torch.optim as optim

# class LassoPyT(nn.Module):
#     def __init__(self, input_size, n_signals=1):
#         super(LassoPyT, self).__init__()
#         self.linear = nn.Linear(input_size, n_signals, bias=False)
    
#     def forward(self, x):
#         return self.linear(x)



# from tools.misc import hrf_func
# import nibabel as nib
# from nilearn.masking import apply_mask, unmask
# import dask.array as da


# Y_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_prep.nii.gz")
# mask_img = nib.load("results/voice-nonvoice-bids/sub003/sw_bold_mask.nii.gz")
# Y = apply_mask(Y_img, mask_img)    

# T, N = Y.shape
# TR = 0.5
# Th = 40
# isignal = 100
# timeline = np.arange(T) * TR
# y = Y[:, isignal]

# delay_h0, disp_h0 = 3, 1
# H = hrf_func(timeline[:Th], delay=delay_h0, disp=disp_h0)

# H = np.pad(H, (0, T - Th), 'constant') if T > Th else H
# H = np.column_stack((np.ones(T), toeplitz(H, np.zeros(T))))
# print(H.shape)



# Ht = torch.from_numpy(H).float()
# yt = torch.from_numpy(Y).float()
# # Yt = torch.from_numpy(Y[:,isignal])
# model = LassoPyT(Ht.shape[1], Y.shape[1])
# # w = lasso_regression(Ht, Y[:,isignal])

# lr=0.005
# max_iter=500
# alpha=2
# criterion = nn.MSELoss(reduction='sum')
# optimizer = optim.Adam(model.parameters(), lr=lr)

# for it in range(max_iter):
#     print(it)
#     optimizer.zero_grad()
#     output = model(Ht)
#     loss = criterion(output, yt) # .unsqueeze(1)
#     l1_loss = alpha * torch.norm(model.linear.weight, p=1)
#     total_loss = loss + l1_loss
#     total_loss.backward()
#     optimizer.step()

# w = model.linear.weight.detach().numpy()
# # return model.linear.weight.detach()

# w = w.T
# xest = w[1:, :]
# # xest, xest_bias = model.coef_[1:], model.coef_[0]

# plt.figure()
# plt.plot(timeline, Y[:,100])
# plt.plot(timeline, xest[:,100])
# plt.show()

