import os, time, shutil

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from io import StringIO

import warnings
warnings.filterwarnings("ignore")

from sklearn.preprocessing import StandardScaler
from scipy.linalg import toeplitz
from scipy import signal, stats
from scipy.signal import find_peaks
import random

import nibabel as nb
from nilearn.image import smooth_img
from nilearn.image import resample_to_img
import nitime.fmri.io as io
from skimage.measure import label
from skimage.color import label2rgb
from scipy import stats, signal
import numpy as np
import nibabel as nib
from nilearn import datasets, image
import os
from pathlib import Path
from scipy.interpolate import interp1d, UnivariateSpline
import os
import shutil
from pathlib import Path
import numpy as np
import nibabel as nib
from nilearn.image import resample_to_img, mean_img, smooth_img, clean_img
from nilearn.masking import apply_mask
from nilearn.signal import clean
from scipy.interpolate import interp1d
from scipy import stats
from joblib import Parallel, delayed
import matplotlib.pyplot as plt
from scipy.ndimage import label
from skimage.color import label2rgb
import time
from tqdm import tqdm


import numpy as np
import pandas as pd
import os
import nibabel as nb

import matplotlib.pyplot as plt
import ipywidgets as widgets
from IPython.display import display
import numpy as np
from matplotlib.widgets import  RectangleSelector
import matplotlib.patches as patches
import matplotlib.cm as cm
from matplotlib.ticker import MaxNLocator
import copy


from nilearn import datasets
from nilearn.image import resample_to_img


# Atlas loading functions
ATLAS_CONFIGS = {
    'aal': ('fetch_atlas_aal', {'version': 'SPM12'}, 'maps', 'indices', 'nearest'),
    'ho_cort': ('fetch_atlas_harvard_oxford', {'atlas_name': 'cort-prob-1mm'}, 'filename', None, 'continuous'),
    'ho_cort_maxprob': ('fetch_atlas_harvard_oxford', {'atlas_name': 'cort-maxprob-thr50-1mm'}, 'filename', None, 'nearest'),
    'ho_sub': ('fetch_atlas_harvard_oxford', {'atlas_name': 'sub-prob-1mm'}, 'filename', None, 'continuous'),
    'ho_sub_maxprob': ('fetch_atlas_harvard_oxford', {'atlas_name': 'sub-maxprob-thr50-1mm'}, 'filename', None, 'nearest'),
    'msdl': ('fetch_atlas_msdl', {}, 'maps', None, 'continuous'),
    'pauli': ('fetch_atlas_pauli_2017', {}, 'maps', None, 'continuous'),
    'yeo_thin_17': ('fetch_atlas_yeo_2011', {}, 'thin_17', None, 'nearest'),
    'yeo_thick_17': ('fetch_atlas_yeo_2011', {}, 'thick_17', None, 'nearest'),
    'basc': ('fetch_atlas_basc_multiscale_2015', {}, None, None, 'nearest'),
    # 'seitzman': (None, {}, 'utilities/Parcels_MNI_111.nii', None, 'nearest')
}


# def get_roinumber_mask(template_img):
#     roi_mask = (template_img == 2001)
#     aal_atlas = datasets.fetch_atlas_aal()
#     # dict_keys(['description', 'maps', 'labels', 'indices'])
#     # if label in aal_regions:
#     template_img = nib.load(aal_atlas['maps'])
#     aal_labels = aal_atlas['labels']
#     roi_numbers = list(map(int, aal_atlas['indices']))
#     print(roi_numbers)
#     # 



def load_atlas_metadata(atlas):

    if atlas not in ATLAS_CONFIGS:
        raise ValueError(f'Unknown atlas: {atlas}')
    
    fetch_func, fetch_args, maps_key, indices_key, interpolation = ATLAS_CONFIGS[atlas]

    if fetch_func:
        atlas_data = getattr(datasets, fetch_func)(**fetch_args)
        atlas_filename = atlas_data[maps_key] if maps_key else atlas_data
        roi_numbers = list(map(int, atlas_data[indices_key])) if indices_key else None
    else:
        atlas_filename = maps_key
        roi_numbers = None

    if roi_numbers is None:
        N_labels = int(atlas.split('basc')[-1]) if 'basc' in atlas else 333
        roi_numbers = list(range(1, N_labels + 1))
    else:
        N_labels = len(roi_numbers)

    return atlas_filename, roi_numbers, N_labels, interpolation

def load_atlas(atlas):

    if atlas not in ATLAS_CONFIGS:
        raise ValueError(f'Unknown atlas: {atlas}')
    
    fetch_func, fetch_args, _, _, _ = ATLAS_CONFIGS[atlas]
    
    if fetch_func:
        return getattr(datasets, fetch_func)(**fetch_args)
    else:
        return datasets.fetch_coords_seitzman_2018(ordered_regions=True, legacy_format=True)




if __name__ == "__main__":

    atlas = load_atlas('aal')

    # for atlas in ATLAS_CONFIGS.keys():
    #    print(atlas)
    #    fetch_func, fetch_args, maps_key, indices_key, interpolation = ATLAS_CONFIGS[atlas]
    #    print(fetch_func)
    #    if fetch_func:
    #       atlas_data = getattr(datasets, fetch_func)(**fetch_args)
    #       print(atlas_data)
#     atlas_filename = atlas_data[maps_key] if maps_key else atlas_data
    #     roi_numbers = list(map(int, atlas_data[indices_key])) if indices_key else None
    # else:
    #     atlas_filename = maps_key
    #     roi_numbers = None

    # if roi_numbers is None:
    #     N_labels = int(atlas.split('basc')[-1]) if 'basc' in atlas else 333
    #     roi_numbers = list(range(1, N_labels + 1))
    # else:
    #     N_labels = len(roi_numbers)

    # return atlas_filename, roi_numbers, N_labels, interpolation

    # a = load_atlas('ho_cort_maxprob')
    # print(a)

    # Atlas loading functions
    ATLAS_CONFIGS = {
        'aal': ('fetch_atlas_aal', {'version': 'SPM12'}, 'maps', 'indices', 'nearest'),
        'ho_cort': ('fetch_atlas_harvard_oxford', {'name': 'cort-prob-1mm'}, 'filename', None, 'continuous'),
        'ho_cort_maxprob': ('fetch_atlas_harvard_oxford', {'name': 'cort-maxprob-thr50-1mm'}, 'filename', None, 'nearest'),
        # 'ho_sub': ('fetch_atlas_harvard_oxford', {'name': 'sub-prob-1mm'}, 'filename', None, 'continuous'),
        # 'ho_sub_maxprob': ('fetch_atlas_harvard_oxford', {'name': 'sub-maxprob-thr50-1mm'}, 'filename', None, 'nearest'),
        # 'msdl': ('fetch_atlas_msdl', {}, 'maps', None, 'continuous'),
        # 'pauli': ('fetch_atlas_pauli_2017', {}, 'maps', None, 'continuous'),
        # 'yeo_thin_17': ('fetch_atlas_yeo_2011', {}, 'thin_17', None, 'nearest'),
        # 'yeo_thick_17': ('fetch_atlas_yeo_2011', {}, 'thick_17', None, 'nearest'),
        # 'basc': ('fetch_atlas_basc_multiscale_2015', {}, None, None, 'nearest'),
        # 'seitzman': (None, {}, 'utilities/Parcels_MNI_111.nii', None, 'nearest')
    }




# # def get_roinumber_mask(template_img):
# #     roi_mask = (template_img == 2001)
# #     aal_atlas = datasets.fetch_atlas_aal()
# #     # dict_keys(['description', 'maps', 'labels', 'indices'])
# #     # if label in aal_regions:
# #     template_img = nib.load(aal_atlas['maps'])
# #     aal_labels = aal_atlas['labels']
# #     roi_numbers = list(map(int, aal_atlas['indices']))
# #     print(roi_numbers)
# #     # 



# def load_atlas_metadata(atlas):

#     if atlas not in ATLAS_CONFIGS:
#         raise ValueError(f'Unknown atlas: {atlas}')
    
#     fetch_func, fetch_args, maps_key, indices_key, interpolation = ATLAS_CONFIGS[atlas]

#     if fetch_func:
#         atlas_data = getattr(datasets, fetch_func)(**fetch_args)
#         atlas_filename = atlas_data[maps_key] if maps_key else atlas_data
#         roi_numbers = list(map(int, atlas_data[indices_key])) if indices_key else None
#     else:
#         atlas_filename = maps_key
#         roi_numbers = None

#     if roi_numbers is None:
#         N_labels = int(atlas.split('basc')[-1]) if 'basc' in atlas else 333
#         roi_numbers = list(range(1, N_labels + 1))
#     else:
#         N_labels = len(roi_numbers)

#     return atlas_filename, roi_numbers, N_labels, interpolation






# def load_atlas_metadata(atlas):
#   interpolation = 'nearest'
#   if atlas == 'aal':
#     aal = datasets.fetch_atlas_aal(version='SPM12')
#     atlas_filename = aal.maps
#     roi_numbers = list(map(int, aal.indices))
#     N_labels = len(roi_numbers)
#   elif atlas == 'ho_cort':
#     ho = datasets.fetch_atlas_harvard_oxford('cort-prob-1mm')
#     atlas_filename = ho['filename']
#     N_labels = 48
#     roi_numbers = list(range(1,N_labels+1))
#     interpolation = 'continuous'
#   elif atlas == 'ho_cort_maxprob':
#     ho = datasets.fetch_atlas_harvard_oxford('cort-maxprob-thr50-1mm')
#     atlas_filename = ho['filename']
#     N_labels = 48
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'ho_sub':
#     ho = datasets.fetch_atlas_harvard_oxford('sub-prob-1mm')
#     atlas_filename = ho['filename']
#     N_labels = 21
#     roi_numbers = list(range(1,N_labels+1))
#     interpolation = 'continuous'
#   elif atlas == 'ho_sub_maxprob':
#     ho = datasets.fetch_atlas_harvard_oxford('sub-maxprob-thr50-1mm')
#     atlas_filename = ho['filename']
#     N_labels = 21
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'msdl':
#     msdl = datasets.fetch_atlas_msdl()
#     atlas_filename = msdl.maps
#     N_labels = 39
#     roi_numbers = list(range(1,N_labels+1))
#     interpolation = 'continuous'
#   elif atlas == 'pauly':
#     atlas = datasets.fetch_atlas_pauli_2017()
#     atlas_filename = atlas.maps
#     N_labels = 16
#     roi_numbers = list(range(1,N_labels+1))
#     interpolation = 'continuous'
#   elif atlas == 'yeo_thin_17':
#     yeo = datasets.fetch_atlas_yeo_2011()
#     atlas_filename = yeo['thin_17'] # thick_17
#     N_labels = 17
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'yeo_thick_17':
#     yeo = datasets.fetch_atlas_yeo_2011()
#     atlas_filename = yeo['thick_17'] # thick_17
#     N_labels = 17
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc007':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale007
#     N_labels = 7
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc012':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale012
#     N_labels = 12
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc020':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale020
#     N_labels = 20
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc036':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale036
#     N_labels = 36
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc064':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale064
#     N_labels = 64
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc122':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale122
#     N_labels = 122
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc197':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale197
#     N_labels = 197
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc325':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale325
#     N_labels = 325
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'basc444':
#     multiscale = datasets.fetch_atlas_basc_multiscale_2015()
#     atlas_filename = multiscale.scale444
#     N_labels = 444
#     roi_numbers = list(range(1,N_labels+1))
#   elif atlas == 'seitzman':
#     atlas_filename = 'utilities/Parcels_MNI_111.nii'
#     N_labels = 333
#     roi_numbers = list(range(1,N_labels+1))

#   return atlas_filename, roi_numbers, N_labels, interpolation


# def load_atlas(atlas):

#   if atlas == 'aal':
#     return datasets.fetch_atlas_aal(version='SPM12')
#   elif atlas == 'ho_cort':
#     return datasets.fetch_atlas_harvard_oxford('cort-prob-1mm')
#   elif atlas == 'ho_cort_maxprob':
#     return datasets.fetch_atlas_harvard_oxford('cort-maxprob-thr50-1mm')
#   elif atlas == 'ho_sub':
#     return datasets.fetch_atlas_harvard_oxford('sub-prob-1mm')
#   elif atlas == 'ho_sub_maxprob':
#     return datasets.fetch_atlas_harvard_oxford('sub-maxprob-thr50-1mm')
#   elif atlas == 'msdl':
#     return datasets.fetch_atlas_msdl()
#   elif atlas == 'pauly':
#     return datasets.fetch_atlas_pauli_2017()
#   elif atlas == 'yeo':
#     return datasets.fetch_atlas_yeo_2011()
#   elif atlas == 'basc':
#     return datasets.fetch_atlas_basc_multiscale_2015()
#   elif atlas == 'seitzman':
#     return datasets.fetch_coords_seitzman_2018(ordered_regions=True, legacy_format=True)


