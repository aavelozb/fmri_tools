import os, sys, shutil, time
import numpy as np
import matplotlib.pyplot as plt
from math import sqrt
from scipy import signal, interpolate, linalg
from scipy.linalg import toeplitz, solve_triangular
from joblib import Parallel, delayed, cpu_count, Memory
from tqdm import tqdm

# imports from local files
from tools.misc import hrf_func
# from data_manipulation import map_unmasked3d_to_maskedidx




######################### function to perform deconvolution Tikhonov method
# The implementation logic is that it receives a matrix with signals Y 



##################### X deconvolution

### case single HRF
import numpy as np
from scipy import linalg
from scipy.linalg import toeplitz
from math import sqrt
from joblib import Parallel, delayed
from tqdm import tqdm
import time


def soft_threshold(x, alpha):
    return np.sign(x) * np.maximum(np.abs(x) - alpha, 0)

def estimate_active_set(A, b, x, lambda_reg):
    grad = A.T @ (A @ x - b)
    return np.abs(grad) >= lambda_reg * 0.99

def fista_subproblem(A, b, lambda_reg, x0, max_iter=1000, tol=1e-6):
    m, n = A.shape
    L = linalg.norm(A, ord=2)**2
    y = x0.copy()
    t = 1
    x = x0.copy()
    for _ in range(max_iter):
        x_old = x.copy()
        grad = A.T @ (A @ y - b)
        x = soft_threshold(y - grad / L, lambda_reg / L)
        t_new = (1 + np.sqrt(1 + 4 * t**2)) / 2
        y = x + ((t - 1) / t_new) * (x - x_old)
        t = t_new
        if np.linalg.norm(x - x_old) < tol:
            break
    return x

def ira_fista(A, b, lambda_reg, max_outer_iter=10, max_inner_iter=1000, tol=1e-6):
    m, n = A.shape
    x = np.linalg.inv(A.T @ A) @ A.T @ b
    # x = np.zeros(n)
    
    for outer_iter in range(max_outer_iter):
        # Estimate active set W based on KKT residual
        grad = A.T @ (A @ x - b)
        W = np.abs(grad) >= lambda_reg * 0.99
        # W = estimate_active_set(A, b, x, lambda_reg)
        # Solve subproblem on active set W
        AW = A[:, W]
        xW = fista_subproblem(AW, b, lambda_reg, x[W], max_inner_iter, tol)
        # Update solution
        x_new = np.zeros(n)
        x_new[W] = xW
        # Check convergence
        if np.linalg.norm(x_new - x) < tol:
            break
        x = x_new
    return x[1:], x[0]



def deconv_x_fista_single_hrf(yi, Hi, lambdaxiL, L, lambdaxi, T, tol=1e-6, maxit=5000):
    x_est = np.zeros(T+1)
    t, z = 1, x_est.copy()
    patience, max_patience = 0, 4
    for it in range(maxit):
        xold = x_est.copy()
        z = z + Hi.T.dot(yi - Hi.dot(z)) / L
        x_est = np.sign(z) * np.maximum(np.abs(z) - lambdaxiL, 0.)
        t0 = t
        t = (1. + sqrt(1. + 4. * t ** 2)) / 2.
        z = x_est + ((t0 - 1.) / t) * (x_est - xold)
        if np.linalg.norm(x_est - xold) < tol:
            patience += 1
        if patience > max_patience:
            break
    
    return x_est[1:], x_est[0]

def fista_optimized(A, b, lambda_reg, max_iter=1000, tol=1e-6):
    m, n = A.shape
    x0 = np.zeros(n)
    L = linalg.norm(A, ord=2)**2
    y = x0.copy()
    t = 1
    x = x0.copy()

    for i in range(max_iter):
        x_old = x.copy()
        residual = A @ y - b
        grad = A.T @ residual
        x = soft_threshold(y - grad / L, lambda_reg / L)
        t_new = (1 + np.sqrt(1 + 4 * t**2)) / 2
        y = x + ((t - 1) / t_new) * (x - x_old)
        t = t_new
        if np.linalg.norm(x - x_old) < tol:
            break

    return x[1:], x[0]


def deconv_x_fista_voxelwise_hrf(yi, hi, lambda_xi, T, tol=1e-6, maxit=5000):
    Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
    x_est = np.zeros(Hi.shape[1])
    t, z = 1, x_est.copy()
    L = linalg.norm(Hi) ** 2
    lambda_xiL = lambda_xi / L
    patience, max_patience = 0, 4
    # cost, patience, max_patience = float('inf'), 0, 4
    # costs = []
    for it in range(maxit):
        xold = x_est.copy()
        z = z + Hi.T.dot(yi - Hi.dot(z)) / L
        x_est = np.sign(z) * np.maximum(np.abs(z) - lambda_xiL, 0.)
        t0 = t
        t = (1. + sqrt(1. + 4. * t ** 2)) / 2.
        z = x_est + ((t0 - 1.) / t) * (x_est - xold)
        if np.linalg.norm(x_est - xold) < tol:
            patience += 1
        if patience > max_patience:
            break
    return x_est[1:], x_est[0]

        # cost0 = cost
        # cost = 0.5 * linalg.norm(Hi.dot(x_est) - yi) ** 2 + lambda_xi * linalg.norm(x_est, 1)
        # costs.append(cost)
        # if np.abs(cost-cost0) < tol:
        #     patience += 1
        # if patience > max_patience:
        #     break
    
    # return x_est[1:], x_est[0]

# from memory_profiler import profile
# @profile

from sklearn.linear_model import Lasso
import dask.array as da

def deconv_x_fista_voxelwise_hrf(yi, hi, lambda_xi, T, tol=1e-6, maxit=5000):
    Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
    # Y = da.from_array(Y, chunks='auto')
    # Y_df = Y.compute()
    model = Lasso(alpha=lambda_xi)
    model.fit(Hi, yi)
    x = model.coef_
    Xest, Xest_bias = x[1:], x[0]
    return Xest, Xest_bias




def deconv_x_fista(Y, H, lambdax, bias=True, parallel=True, n_jobs=-1, verbose=True):

    T, N = Y.shape
    Th = H.shape[0]
    Nhrfs = H.shape[1] if H.ndim > 1 else 1
    
    if verbose:
        start_time = time.time()

    if Nhrfs == 1:
        print(30*'-' + ' X estimation - FISTA single HRF')
        H_padded = np.pad(H, (0, T - Th), 'constant') if T > Th else H
        Hi = np.column_stack((np.ones(T), toeplitz(H_padded, np.zeros(T))))
        L = linalg.norm(Hi) ** 2
        lambdaxiL = lambdax / L
        p = ({'yi': Y[:, s], 'Hi': Hi, 'L': L, 'lambdaxiL': lambdaxiL, 'lambdaxi': lambdax, 'T': T} for s in range(Y.shape[1]))
        decfun = deconv_x_fista_single_hrf
        # p = ({'b': Y[:, s], 'A': Hi, 'lambda_reg': lambdax} for s in range(Y.shape[1]))
        # decfun = ira_fista
        # decfun = fista_optimized

        Y = da.from_array(Y, chunks='auto')
        Y_df = Y.compute()
        model = Lasso(alpha=lambdax)
        model.fit(Hi, Y_df)
        # Print coefficients
        X = model.coef_.T
        Xest, Xest_bias = X[1:,:], X[0,:]
        return Xest, Xest_bias
    else:
        H_padded = np.pad(H, ((0, T - Th), (0, 0)), 'constant') if T > Th else H
        p = ({'yi': Y[:, s], 'hi': H_padded[:, s], 'lambda_xi': lambdax, 'T': T} for s in range(Y.shape[1]))
        decfun = deconv_x_fista_voxelwise_hrf


    if parallel:
        results = Parallel(n_jobs=n_jobs)(delayed(decfun)(**params) for params in tqdm(p, total=N, desc='(parallel processing)'))
    else:
        results = list(map(lambda params: decfun(**params), tqdm(p, total=N, desc='(parallel processing: off)')))

    if verbose:
        print(f'Elapsed time X estimation ({N} signals): {time.time() - start_time:.4f} seconds')

    Xest, Xest_bias = zip(*results)
    return np.array(Xest).T, np.array(Xest_bias)













if __name__ == "__main__":

    from tools.misc import hrf_func

    T = 1000
    Th = 40
    TR = 0.5
    N = 10000

    timeline = np.arange(T) * TR
    x_true = np.zeros((T, N))
    y = np.zeros((T, N))

    x_true[100, :] = 1
    x_true[700, :] = 1

    h_true = hrf_func(timeline)
    H_true = toeplitz(h_true, np.zeros(T))

    for i in range(N):
        y[:, i] = H_true @ x_true[:, i]

    # y = H_true @ x_true
    # print(x_true.shape, y.shape, h_true.shape, H_true.shape)

    h0 = hrf_func(timeline[:Th], delay=3, disp=1)
    xest, xbias = deconv_x_fista(y, h0, lambdax=1, bias=True, parallel=True, n_jobs=-1, verbose=True)

    # Y = y[:, np.newaxis]
    # X = x_true[:, np.newaxis]
    # hest, hbias = deconvh_tikhonov(Y, X, lambdah=0.5, Th=Th, bias=True, parallel=True, n_jobs=-1, verbose=True)

    plt.figure(figsize=(12,6))
    plt.plot(timeline, x_true[:, 0])
    plt.plot(timeline, xest[:, 0])
    plt.plot(timeline, y[:, 0])
    # plt.figure()
    # plt.plot(timeline[:Th], h_true[:Th])
    # plt.plot(timeline[:Th], h0)
    # plt.plot(timeline[:Th], hest.flatten())
    # plt.figure(figsize=(12,6))
    # plt.plot(costs)

    plt.show()



# def deconv_x_ista_test(yi, hi, lambda_xi, T, tol=1e-6, maxit=5000):
#     Hi = np.column_stack((np.ones(T), toeplitz(hi, np.zeros(T))))
#     x_est = np.zeros(Hi.shape[1])
#     L = linalg.norm(Hi) ** 2 # Lipschitz constant
#     lambda_xiL = lambda_xi / L
#     cost, patience, max_patience = float('inf'), 0, 4
#     costs = []
#     for it in range(maxit):
#         x_est = x_est + np.dot(Hi.T, yi - Hi.dot(x_est)) / L
#         x_est = np.sign(x_est) * np.maximum(np.abs(x_est) - lambda_xiL, 0.)
#         cost0 = cost
#         cost = 0.5 * linalg.norm(Hi.dot(x_est) - yi) ** 2 + lambda_xi * linalg.norm(x_est, 1)
#         costs.append(cost)
#         if np.abs(cost-cost0) < tol:
#             patience += 1
#         if patience > max_patience:
#             break
#     return x_est[1:], x_est[0], costs