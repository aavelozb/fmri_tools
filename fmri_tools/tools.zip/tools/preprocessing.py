import os, time, shutil
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
import nibabel as nib

from scipy import stats
from scipy.fft import fft, ifft, fftfreq
from scipy.interpolate import interp1d, UnivariateSpline

from nilearn.image import resample_to_img, mean_img, smooth_img, clean_img
from nilearn.masking import apply_mask, unmask
from nilearn.signal import clean
from nilearn.datasets import load_mni152_template

from joblib import Parallel, delayed
from tqdm import tqdm

import warnings
warnings.filterwarnings("ignore")
import json


def linear_interpolate_signals(Y0, timeline0, timeline, parallel=False, verbose=False, n_jobs=-1):

    def process_single_signal(y):
        return interp1d(timeline0, y, 
                        kind='linear', bounds_error=False, 
                        fill_value='extrapolate')(timeline)

    desc = 'Interpolation'
        
    if verbose:
        start_time = time.time()
    
    if Y0.ndim == 1:
        return process_single_signal(Y0)
    elif Y0.ndim == 2:
        N = Y0.shape[1]
        if parallel:
            Yinterp = Parallel(n_jobs=n_jobs)(
                delayed(process_single_signal)(y) for y in tqdm(Y0.T, total=N, desc=f'{desc} in parallel')
            )
        else:
            Yinterp = [process_single_signal(y) for y in tqdm(Y0.T, total=N, desc=desc)]
        
        if verbose:
            print(f'Elapsed time for interpolating {N} signals: {time.time() - start_time:.4f} seconds')
        
        return np.array(Yinterp).T
    else:
        raise ValueError('Input signals must be 1D or 2D numpy array')


def rest_IdealFilter(Y, TR, bands, parallel=False, verbose=False, n_jobs=-1):
    """
    Applies an ideal bandpass filter on fMRI data with optional parallel processing.

    Parameters:
    - Y (np.ndarray): Signal data to be filtered.
    - TR (float): Repetition time of the fMRI acquisition.
    - bands (tuple): Low and high frequency cutoffs for filtering.
    - parallel (bool): If True, use parallel processing. Defaults to False.
    - verbose (bool): If True, print elapsed time and show progress bars. Defaults to False.
    - n_jobs (int): Number of jobs for parallel processing. Defaults to -1 (use all processors).

    Returns:
    - np.ndarray: Filtered signal data.
    """
    def process_single_signal(s):
        Ny = s.shape[0]
        fy = fft(np.concatenate((s, np.flipud(s))))
        f = fftfreq(fy.shape[0], TR)
        low, high = bands
        mask = (np.abs(f) >= low) & (np.abs(f) < high)
        fy[~mask] = 0
        y = np.real(ifft(fy))[:Ny]
        return y + np.mean(s)

    desc = 'Ideal Filtering'
        
    if verbose:
        start_time = time.time()
    
    if Y.ndim == 1:
        return process_single_signal(Y)
    elif Y.ndim == 2:
        N = Y.shape[1]
        if parallel:
            Y_filtered = Parallel(n_jobs=n_jobs)(
                delayed(process_single_signal)(s) for s in tqdm(Y.T, total=N, desc=f'{desc} in parallel')
            )
        else:
            Y_filtered = [process_single_signal(s) for s in tqdm(Y.T, total=N, desc=desc)]
        if verbose:
            print(f'Elapsed time for filtering {N} signals: {time.time() - start_time:.4f} seconds')
        return np.array(Y_filtered).T
    else:
        raise ValueError('Input signals must be 1D or 2D numpy array')








