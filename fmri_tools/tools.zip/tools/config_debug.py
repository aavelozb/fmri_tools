import os, json
import numpy as np
from pathlib import Path
import os
from atlases import load_atlas





def check_inputfiles_exists(input_filenames, exts):
    flag_exists = True
    flag_ext_supported = True
    for full_fname in input_filenames:

        flag_ext_ = False
        for ext in exts:
            if full_fname.endswith(ext):
                flag_ext_ = True
        if not flag_ext_:
            print(f'{full_fname} -> extension not supported')
            flag_ext_supported = False

        if not os.path.exists(full_fname): 
            flag_exists = False
            print(f'{full_fname} -> exists = {flag_exists}')
    
    return flag_exists, flag_ext_supported


# check minimal inputs

# keys_mandatory = ['fin-func', 'TR0', 'regx', 'regh']
# for km in keys_mandatory:
#     if km not in input_parameters:
#         print(f"\nThe following input parameters are mandatory:\n{msg_}")
#         return None

config = {
    'fin-func': None, 
    'TR0': None, 
    'regx': None, 
    'regh': None,
    'exp-id': None, 
    'path-output': '.',
    'fin-types': ('.nii.gz', '.nii'),
    'HRF-duration-sec': 20, 
    'n-first-scans-to-eliminate': 0, 
    'TR': 0.5,
    'parallel': True, 
    'n_jobs': -1, 
    'verbose': True,
    'fin-anat': None, 
    'fin-mask': None,
    'path-fin-func': '.', 
    'path-fin-anat': None, 
    'path-fin-mask': None,
    'parcellation-method': None, 
    'flag-use-parcellation-as-mask': False,
    'mask-for-deconv': None, 
    'deconv-hrf-mode': 'fixed-hrf-spm',
    'mask-for-events': None, 
    'rel_height_list': [0.2, 0.3, 0.4, 0.5]
    }

def check_minimim_inputs(config):
    return

input_parameters = {
    'fin-func': 'swbold.nii.gz', 
    'path-fin-func': os.path.join(str(Path.home()), 'data', 'voice-non-voice'),
    'fin-anat': 'anat.nii', 
    'path-fin-anat': os.path.join(str(Path.home()), 'data', 'voice-non-voice'),
    'TR0': 2, 
    'regx': 0.3, 
    'regh': 0.3,
    'flag-use-parcellation-as-mask': True,
    'parcellation-method': 'aal',
    'n-first-scans-to-eliminate': 5
    }


config.update(input_parameters)


# fuse inputs paths and filenames
config['fin-anat'] = os.path.join(config['path-fin-anat'], config['fin-anat'])
config['fin-func'] = os.path.join(config['path-fin-func'], config['fin-func'])
# elif config['fin-mask'] is not None:
#     config['fin-mask'] = os.path.join(config['path-fin-mask'], 
#                                 config['fin-mask'])

# check input files exists
filenames = []

if not isinstance(config['fin-func'], list):
    config['fin-func'] = [config['fin-func']]

if config['fin-anat'] is not None:
    if not isinstance(config['fin-anat'], list):
        config['fin-anat'] = [config['fin-anat']]

if config['flag-use-parcellation-as-mask']:

    if config['parcellation-method'] is None:
        raise ValueError(f"""
                         If 'flag-use-parcellation-as-mask' is True, 
                         you must provide a valid 'parcellation-method'.
                         Valid methods: 
                                'aal'"""
                         )
    config['fin-mask'] = [load_atlas(config['parcellation-method'])['maps']]

filenames += config['fin-func']
filenames += config['fin-anat']
filenames += config['fin-mask']

print(filenames)
flag_exists, flag_ext_supported = check_inputfiles_exists( filenames, config['fin-types'] )
if flag_exists:
    print('inputs files checked')




# def check_files_exists(config, process='init'):
#     # print(os.path.splitext(config['fin-func']))


#     is_valid = lambda: os.path.exists(config)

    
#     for ext in config['fin-types']:
#         
#             if config['exp-id'] is None:
#                 config['exp-id'] = config['fin-func'].replace(ext, '')
#             flag_ext = True
#     if not flag_ext:
#         raise ValueError(f"Input file type is not supported. Provide a file within the types {config['fin-types']}.")
#     if 

#     return

# def check_config_file(config, process='init'):
#     ### checking that the regularization parameters are correctly provided
#     if config['regx'] is None or config['regh'] is None:
#         reg_parameters_ok = False
#     elif isinstance(config['regx'], (float, int)) and isinstance(config['regh'], (float, int)):
#         config['regx'] = [config['regx']]
#         config['regh'] = [config['regh']]
#         reg_parameters_ok = True
#     elif hasattr(config['regx'], '__len__') and hasattr(config['regh'], '__len__') and len(config['regx']) == len(config['regh']):
#         reg_parameters_ok = True
#     else:
#         reg_parameters_ok = False

#     if not reg_parameters_ok:
#         print(config['regx'], config['regh'])
#         raise ValueError("regx and regh must be either two numbers or lists/arrays of the same length.")

#     return


# def print_config_file(config, process='init'):
#     return


# def load_config(config, process='init'):

#     if process =='init':
#         config

#     return


# check_files_exists()

# def create_config(input_parameters):

#     msg_ = """
#     'fin-func' (str): full filename, otherwise fill the field 'path-fin-func'.
#     'TR0' (int/float): time of repetition in seconds.
#     'regx' (int/float or list/array): regularization parameter for estimating x.
#     'regh' (int/float or list/array): regularization parameter for estimating the HRF.
#     """
    
#     if not isinstance(input_parameters, dict):
#         print(f"\nThe input parameters must be a dictionary with at least the following parameters:\n{msg_}")
#         return None






#     ########## output directory
#     config['path-output'] = os.path.join(config['path-output'], 
#                                         'output-'+config['exp-id'])
#     if not os.path.exists(config['path-output']):
#         os.mkdir(config['path-output'])


#     ########## some output filenames
#     config['fout-preproc-func'] = os.path.join(
#         config['path-output'],
#         f"prep-func-{config['exp-id']}.nii.gz"
#         )
#     config['fout-preproc-anat'] = os.path.join(
#         config['path-output'],
#         f"prep-anat-{config['exp-id']}.nii.gz"
#         )
#     config['fout-preproc-mask'] = os.path.join(
#         config['path-output'],
#         f"mask-{config['exp-id']}.nii.gz"
#         )
#     if config['mask-for-deconv'] is None:
#         config['mask-for-deconv'] = config['fout-preproc-mask']
#     if config['mask-for-events'] is None:
#         config['mask-for-events'] = config['fout-preproc-mask']


#     config['fin-deconv'] = config['fout-preproc-func']

#     config['fout-deconvx-0'] = []
#     config['fout-deconvx-bias-0'] = []
#     config['fout-deconvh-0'] = []
#     config['fout-deconvh-bias-0'] = []
#     for regx, regh in zip(config['regx'], config['regh']):
#         regx_str = str(regx).replace('.', 'p')
#         regh_str = str(regh).replace('.', 'p')
#         config['fout-deconvx-0'].append(
#             os.path.join(config['path-output'], f'deconvx0-{regx_str}.nii.gz'))
#         config['fout-deconvx-bias-0'].append(
#             os.path.join(config['path-output'], f'deconvx0-bias-{regx_str}.nii.gz'))
#         config['fout-deconvh-0'].append(
#             os.path.join(config['path-output'], f'deconvh0-{regh_str}.nii.gz'))
#         config['fout-deconvh-bias-0'].append(
#             os.path.join(config['path-output'], f'deconvh0-bias-{regh_str}.nii.gz'))

#     ############## determining inputs files for event detection
#     def create_filename_for_events(fname):
#         exts = ['.nii.gz', '.nii']
#         if os.path.sep in fname:
#             fname_list = fname.split(os.path.sep)
#         fname = fname_list[-1]
#         for ext in exts:
#             if fname.endswith(ext):
#                 fname = fname.replace(ext, '.npz')
#                 fname = 'ev-'+fname
#         fname_list[-1] = fname
#         return os.path.sep.join( fname_list )

#     config['fin-events'] = [config['fout-preproc-func']]
#     config['fout-events'] = [create_filename_for_events(
#         config['fout-preproc-func']
#         )]

#     for fname in config['fout-deconvx-0']:
#         config['fin-events'].append(fname)
#         config['fout-events'].append(
#             create_filename_for_events(fname))
#     # for f1,f2 in zip(config['fin-events'], config['fout-events']):
#     #     print(f1)
#     #     print('\t\t', f2)

#     for k in config:
#         if isinstance(config[k], np.ndarray):
#             config[k] = config[k].tolist()

#     with open(f"{os.path.join(config['path-output'], config['exp-id'])}.json", "w") as outfile:
#         json.dump(config, 
#                 outfile, 
#                 #   separators=(',', ':'), 
#                 sort_keys=False, 
#                 indent=4)
#         print(f"Configuration file saved in {os.path.join(config['path-output'], config['exp-id'])}.json")
        
#     return config
