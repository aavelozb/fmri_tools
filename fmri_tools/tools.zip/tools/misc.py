from __future__ import division
import os
import glob
from functools import partial
import numpy as np
import scipy.stats as sps
from scipy.stats import rankdata
import nibabel as nib
from nilearn.masking import apply_mask, unmask
import nibabel as nib


def hrf_func(t, delay=6, disp=1):
    return spm_hrf_compat(t, 
                          peak_delay=delay, 
                          under_delay=16,
                          peak_disp=disp,
                          under_disp=1,
                          p_u_ratio = 6,
                          normalize=True
                          )


def get_bigmatrix(D, nrows=4, annotations=None): # 3D to 2D (concatenating in the 3D axis)
    xdim, ydim, zdim = D.shape
    ncols = int(np.ceil(zdim / nrows))
    Manat = np.zeros((ydim * nrows, xdim * ncols))
    coordinates = [] # of points in annorations
    for r in range(nrows):
        for c in range(ncols):
            sl = c + ncols * r
            if sl < zdim:
                Manat[r * ydim:(r + 1) * ydim, c * xdim:(c + 1) * xdim] = D[:, ::-1, sl].T
    return Manat


def plot_vol_with_click(vol_data, rgb=False, nrows=4, save_path=None, 
                        fig_name=None, colormap='gray',
                        docolormap=False, title=None):

    if isinstance(vol_data, str) and os.path.isfile(vol_data):
        img = nib.load(vol_data)
        data = img.get_fdata()
    elif isinstance(vol_data, nib.Nifti1Image) or isinstance(vol_data, nib.Nifti2Image):
        data = vol_data.get_fdata()
    elif isinstance(vol_data, np.ndarray):
        data = vol_data
    else:
        raise ValueError('Input must be a .nii/.nii.gz filename, nifti object, or numpy array')

    M, _ = get_bigmatrix(data, nrows=nrows)

    fig, ax = plt.subplots(frameon=False)
    im = ax.imshow(M, cmap=colormap)
    ax.set_xticks([])
    ax.set_yticks([])
    for spine in ax.spines.values():
        spine.set_visible(False)
    plt.tight_layout(pad=0)

    if save_path is not None and fig_name is not None:
        fname = os.path.join(save_path, f'{fig_name}.png')
        plt.savefig(fname, bbox_inches='tight', dpi=300)
        plt.close()
    else:
        cid = fig.canvas.mpl_connect('button_press_event', onclick)
        plt.show()

    if docolormap:
        plot_colormap_bar('viridis', 
                  vmin=data.min(), 
                  vmax=data.max(), 
                  title=title)

    return fig, ax

def plot_colormap_bar(colormap, vmin=0, vmax=1, title='Colormap'):
    fig, ax = plt.subplots(figsize=(6, 1))
    norm = plt.Normalize(vmin=vmin, vmax=vmax)
    plt.colorbar(plt.cm.ScalarMappable(norm=norm, cmap=colormap), cax=ax, orientation='horizontal')
    plt.title(title)
    plt.tight_layout()
    plt.show()


def map_maskedidx_to_unmasked3d(idx, mask_img):
    mask_data = mask_img.get_fdata()
    mask_indices = np.where(mask_data > 0)
    if idx >= len(mask_indices[0]):
        return None
    return (int(mask_indices[0][idx]), int(mask_indices[1][idx]), int(mask_indices[2][idx]))


def map_unmasked3d_to_maskedidx(coord, mask_img):
    mask_data = mask_img.get_fdata()
    x, y, z = coord    
    if x < 0 or y < 0 or z < 0 or x >= mask_data.shape[0] or y >= mask_data.shape[1] or z >= mask_data.shape[2]:
        return None
    if mask_data[x, y, z] == 0:
        return None    
    mask_indices = np.where(mask_data > 0)
    for idx, (mx, my, mz) in enumerate(zip(*mask_indices)):
        if (x, y, z) == (mx, my, mz):
            print('idx:', idx)

            return idx
    # the coordinate was not found in the mask
    return None



def map_2d_to_3d(coord_2d, vol_data_shape, nrows=4):
    xdim, ydim, zdim = vol_data_shape
    ncols = int(np.ceil(zdim / nrows))

    coord_x, coord_y = coord_2d

    r = coord_y // ydim
    c = coord_x // xdim
    z_index = r * ncols + c

    if z_index < zdim:
        x = coord_x % xdim
        y = coord_y % ydim
        return (x, y, z_index)
    else:
        return None




def map_3d_to_2d(coord_3d, vol_data_shape, nrows=4):
    xdim, ydim, zdim = vol_data_shape
    x, y, z = coord_3d
    ncols = int(np.ceil(zdim / nrows))

    r = z // ncols
    c = z % ncols

    if r < nrows:
        coord_x = c * xdim + x
        coord_y = r * ydim + (ydim - y - 1)
        return (coord_x, coord_y)
    else:
        return None


def get_filenames(source_path, keyword):
    source_path = os.path.join(source_path, '')    
    return glob.glob(f'{source_path}*{keyword}*')


def save_config_to_file(config):
    fname = os.path.join(config['path-output'], 'info-'+config['exp-id']+'.txt')
    with open(fname, 'w') as file:
        for key, value in config.items():
            file.write(f'{key}: {value}\n')
    print(f'configuration saved into: {fname}')


def load_config_from_file(filename):
    loaded_dict = {}
    with open(filename, 'r') as file:
        for line in file:
            key, value = line.strip().split(': ', 1)
            loaded_dict[key] = value
    return loaded_dict


def update_dict_in_file(filename, updates):
    existing_dict = {}
    try:
        with open(filename, 'r') as file:
            for line in file:
                key, value = line.strip().split(': ', 1)
                existing_dict[key] = value
    except FileNotFoundError:
        existing_dict = {}

    existing_dict.update(updates)

    with open(filename, 'w') as file:
        for key, value in existing_dict.items():
            file.write(f"{key}: {value}\n")

# update_dict_in_file('example.txt', {'age': 26, 'country': 'Wonderland'})


# # Saving a dictionary
# example_dict = {'name': 'Alice', 'age': 25, 'city': 'Wonderland'}
# save_dict_to_file(example_dict, 'example.txt')

# # Loading a dictionary
# loaded_dict = load_dict_from_file('example.txt')
# print(loaded_dict)


def concatenate_vol_data(vol_data, nrows=4):
    xdim, ydim, zdim = vol_data.shape[:3]
    ncols = int(np.ceil(zdim / nrows))
    mat_data = np.zeros((ydim * nrows, xdim * ncols))
    for r in range(nrows):
        for c in range(ncols):
            sl = c + ncols * r
            if sl < zdim:
                mat_data[r * ydim:(r + 1) * ydim, c * xdim:(c + 1) * xdim] = vol_data[:, :, sl].T
    return mat_data



import os, random
import nibabel as nib


def generate_distinct_colors(n_segments):
    colors = [
        '#ffcccc',  # light red
        '#ccffcc',  # light green
        '#cce0ff',  # light blue
        '#ffffcc',  # light yellow
        '#ffccff',  # light purple
        '#ccffff',  # light cyan
        '#ffcc99',  # light orange
        '#e6ccff',  # light violet
        '#99ffcc'   # light mint
    ]
    random.shuffle(colors) # shuffle colors
    segment_colors = [] # ensure consecutive segments have different colors
    last_color = None
    for i in range(n_segments):
        available_colors = [c for c in colors if c != last_color]
        if not available_colors:
            available_colors = [c for c in colors if c != last_color]
        color = random.choice(available_colors)
        segment_colors.append(color)
        last_color = color
    return segment_colors








def reho(data, mask, nvoxel=27):
    """
    Calculate Regional Homogeneity (ReHo) for fMRI data.
    
    Parameters:
    data : 4D numpy array (time x x x y x z)
        Input fMRI data
    mask : 3D numpy array
        Brain mask
    nvoxel : int
        Number of neighboring voxels (27, 19, or 7)
    
    Returns:
    reho_map : 3D numpy array
        ReHo map
    """
    if nvoxel not in [27, 19, 7]:
        raise ValueError("nvoxel must be 27, 19, or 7")
    
    t, x, y, z = data.shape
    reho_map = np.zeros((x, y, z))
    
    # Create neighborhood masks
    if nvoxel == 27:
        neighbors = np.ones((3, 3, 3))
    elif nvoxel == 19:
        neighbors = np.ones((3, 3, 3))
        neighbors[0, 0, 0] = neighbors[0, 2, 0] = neighbors[2, 0, 0] = neighbors[2, 2, 0] = 0
        neighbors[0, 0, 2] = neighbors[0, 2, 2] = neighbors[2, 0, 2] = neighbors[2, 2, 2] = 0
    else:  # nvoxel == 7
        neighbors = np.zeros((3, 3, 3))
        neighbors[1, 1, 1] = neighbors[0, 1, 1] = neighbors[2, 1, 1] = 1
        neighbors[1, 0, 1] = neighbors[1, 2, 1] = neighbors[1, 1, 0] = neighbors[1, 1, 2] = 1
    
    # Calculate ranks
    ranked_data = rankdata(data, axis=0, method='average')
    
    # Calculate ReHo
    for i in range(1, x-1):
        for j in range(1, y-1):
            for k in range(1, z-1):
                if mask[i, j, k]:
                    neighborhood = ranked_data[:, i-1:i+2, j-1:j+2, k-1:k+2]
                    mask_neighborhood = mask[i-1:i+2, j-1:j+2, k-1:k+2] * neighbors
                    if np.sum(mask_neighborhood) >= nvoxel:
                        valid_data = neighborhood[:, mask_neighborhood.astype(bool)]
                        reho_map[i, j, k] = kendall_w(valid_data)
    
    return reho_map

def kendall_w(data):
    """
    Calculate Kendall's coefficient of concordance W.
    
    Parameters:
    data : 2D numpy array (time x voxels)
        Ranked data for a neighborhood
    
    Returns:
    w : float
        Kendall's W
    """
    n, k = data.shape
    r_mean = np.mean(data, axis=1)
    s = np.sum((data.T - r_mean) ** 2)
    w = 12 * s / (k**2 * (n**3 - n))
    return w




####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
####################################################################################
# This was copied from Fabian Predregosa's Toolbox, who also copied it from 
# nipy (with removed dependency from sympy)

""" This module provides definitions of various hemodynamic response
functions (hrf).

In particular, it provides Gary Glover's canonical HRF, AFNI's default
HRF, and a spectral HRF.

The Glover HRF is based on:

@article{glover1999deconvolution,
  title={{Deconvolution of impulse response in event-related BOLD fMRI}},
  author={Glover, G.H.},
  journal={NeuroImage},
  volume={9},
  number={4},
  pages={416--429},
  year={1999},
  publisher={Orlando, FL: Academic Press, c1992-}
}

This parametrization is from fmristat:

http://www.math.mcgill.ca/keith/fmristat/

fmristat models the HRF as the difference of two gamma functions, ``g1``
and ``g2``, each defined by the timing of the gamma function peaks
(``pk1, pk2``) and the FWHMs (``width1, width2``):

   raw_hrf = g1(pk1, width1) - a2 * g2(pk2, width2)

where ``a2`` is the scale factor for the ``g2`` gamma function.  The
actual hrf is the raw hrf set to have an integral of 1.

fmristat used ``pk1, width1, pk2, width2, a2 = (5.4 5.2 10.8 7.35
0.35)``.  These are parameters to match Glover's 1 second duration
auditory stimulus curves.  Glover wrote these as:

   y(t) = c1 * t**n1 * exp(t/t1) - a2 * c2 * t**n2 * exp(t/t2)

with ``n1, t1, n2, t2, a2 = (6.0, 0.9, 12, 0.9, 0.35)``.  The difference
between Glover's expression and ours is because we (and fmristat) use
the peak location and width to characterize the function rather than
``n1, t1``.  The values we use are equivalent.  Specifically, in our
formulation:

>>> n1, t1, c1 = gamma_params(5.4, 5.2)
>>> np.allclose((n1-1, t1), (6.0, 0.9), rtol=0.02)
True
>>> n2, t2, c2 = gamma_params(10.8, 7.35)
>>> np.allclose((n2-1, t2), (12.0, 0.9), rtol=0.02)
True
"""

# SPMs HRF
def spm_hrf_compat(t,
                   peak_delay=6,
                   under_delay=16,
                   peak_disp=1,
                   under_disp=1,
                   p_u_ratio = 6,
                   normalize=True,
                  ):
    """ SPM HRF function from sum of two gamma PDFs

    This function is designed to be partially compatible with SPMs `spm_hrf.m`
    function.

    The SPN HRF is a *peak* gamma PDF (with location `peak_delay` and dispersion
    `peak_disp`), minus an *undershoot* gamma PDF (with location `under_delay`
    and dispersion `under_disp`, and divided by the `p_u_ratio`).

    Parameters
    ----------
    t : array-like
        vector of times at which to sample HRF
    peak_delay : float, optional
        delay of peak
    peak_disp : float, optional
        width (dispersion) of peak
    under_delay : float, optional
        delay of undershoot
    under_disp : float, optional
        width (dispersion) of undershoot
    p_u_ratio : float, optional
        peak to undershoot ratio.  Undershoot divided by this value before
        subtracting from peak.
    normalize : {True, False}, optional
        If True, divide HRF values by their sum before returning.  SPM does this
        by default.

    Returns
    -------
    hrf : array
        vector length ``len(t)`` of samples from HRF at times `t`

    Notes
    -----
    See ``spm_hrf.m`` in the SPM distribution.
    """
    if len([v for v in [peak_delay, peak_disp, under_delay, under_disp]
            if v <= 0]):
        raise ValueError("delays and dispersions must be > 0")
    # gamma.pdf only defined for t > 0
    hrf = np.zeros(t.shape, dtype=np.dtype('float'))
    pos_t = t[t > 0]
    peak = sps.gamma.pdf(pos_t,
                         peak_delay / peak_disp,
                         loc=0,
                         scale=peak_disp)
    undershoot = sps.gamma.pdf(pos_t,
                               under_delay / under_disp,
                               loc=0,
                               scale=under_disp)
    hrf[t > 0] = peak - undershoot / p_u_ratio
    if not normalize:
        return hrf
    return hrf / np.max(hrf)


def spmt(t):
    """ SPM canonical HRF, HRF values for time values `t`

    This is the canonical HRF function as used in SPM. It
    has the following defaults:
                                                defaults
                                                (seconds)
    delay of response (relative to onset)         6
    delay of undershoot (relative to onset)      16
    dispersion of response                        1
    dispersion of undershoot                      1
    ratio of response to undershoot               6
    onset (seconds)                               0
    length of kernel (seconds)                   32
    """
    return spm_hrf_compat(t, normalize=True)


def dspmt(t):
    """ SPM canonical HRF derivative, HRF derivative values for time values `t`

    This is the canonical HRF derivative function as used in SPM.

    It is the numerical difference of the HRF sampled at time `t` minus the
    values sampled at time `t` -1
    """
    t = np.asarray(t)
    return spmt(t) - spmt(t - 1)


def ddspmt(t):
    """ SPM canonical HRF dispersion derivative, values for time values `t`

    This is the canonical HRF dispersion derivative function as used in SPM.

    It is the numerical difference between the HRF sampled at time `t`, and
    values at `t` for another HRF shape with a small change in the peak
    dispersion parameter (``peak_disp`` in func:`spm_hrf_compat`).
    """
    _spm_dd_func = partial(spm_hrf_compat, normalize=True, peak_disp=1.01)
    return (spmt(t) - _spm_dd_func(t)) / 0.01
